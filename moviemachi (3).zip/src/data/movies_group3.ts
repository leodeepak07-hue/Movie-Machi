import { Movie } from "../types";

export const moviesGroup3: Movie[] = [
  {
    title: "Vaa Vaathiyaar (2026)",
    image: "https://imgs.search.brave.com/BfLxD9qpkJa8YpEuk_BR2QW8TTPLk7LnflKCh0fOjZ4/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9wcmV2/aWV3LnJlZGQuaXQv/bW92aWUtcmV3cml0/ZS12YWEtdmFhdGhp/eWFhci0yMDI2LXYw/LXVhZW00bnVpaGlk/ZzEuanBnP3dpZHRo/PTEwNjcmZm9ybWF0/PXBqcGcmYXV0bz13/ZWJwJnM9MzY4NmY1/MThhOWFjN2RkZmM4/N2IwMzgwNjhlYjlj/ZmIyZWY1YWZlYg",
    movieName: "Vaa Vaathiyaar (2026)",
    director: "Nalan Kumarasamy",
    starring: "Karthi, Sathyaraj, Krithi Shetty",
    genres: ["Action", "Comedy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "5.7/10",
    lastUpdated: "28 January 2026",
    links: [
      { label: "Download 360p", url: "https://s01.hotshare.link/Moviesda.Mobi_-_Vaa_Vaathiyaar_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://dl3.biggshare.xyz/Moviesda.Mobi_-_Vaa_Vaathiyaar_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://dl9.biggshare.xyz/Moviesda.Mobi_-_Vaa_Vaathiyaar_2026_Original_1080p_HD__3.5_GB_.mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.rsvp_-_Vaa_Vaathiyaar_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_Tam__Tel__Hin__Mal__Kan_-_DD5.1_-_640Kbps__AAC_-_6.8GB_-_ESub.mkv?token=bf28be515111627f286694923391945b&exp=1779990399", className: "K4" }
    ],
    watchUrl: "https://s01.hotshare.link/Moviesda.Mobi_-_Vaa_Vaathiyaar_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Sirai (2025)",
    image: "https://imgs.search.brave.com/jtRUTdEJEUYGPfnEzKPp3UqRphcXZWPRlUXgKrgFyOQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL1NpcmFpX0dh/bGxlcnktODA3YzU5/MjAtNzgzOC0xMWYw/LThkZjMtZGIwMWQx/YmFhNDQ0LmpwZz9p/bT1SZXNpemUsd2lk/dGg9MzIw",
    movieName: "Sirai (2025)",
    director: "Suresh Rajakumari",
    starring: "Vikram Prabhu, L. K. Akshay Kumar, Anishma Anilkumar",
    genres: ["Action", "Drama", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.4/10",
    lastUpdated: "23 January 2026",
    links: [
      { label: "Download 360p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTM4MzM1ODc2NmU1ZGNkOGY4MTM5ZGE1NmVkYzJlY2UwJmV4cD0xNzc5ODU0MTQyJnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvU2lyYWkgKDIwMjUpL1NpcmFpIChPcmlnaW5hbCkvU2lyYWkgKDM2MHAgSEQpL01vdmllc2RhLk1vYmkgLSBTaXJhaSAyMDI1IE9yaWdpbmFsIDM2MHAgSEQubXA0", className: "p480" },
      { label: "Download 720p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTQ3ZDE0NzBhZDQyNWUxNTFhOWMwNzQ4ZTYwMTg2YWFkJmV4cD0xNzc5ODU0MTY2JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvU2lyYWkgKDIwMjUpL1NpcmFpIChPcmlnaW5hbCkvU2lyYWkgKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBTaXJhaSAyMDI1IE9yaWdpbmFsIDcyMHAgSEQubXA0", className: "p720" },
      { label: "Download 1080p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTU0NDE3OTA4NWY2YTFiOTk4ZDc0Yzc3ZTRiOWM1MmE1JmV4cD0xNzc5ODU0MTg4JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvU2lyYWkgKDIwMjUpL1NpcmFpIChPcmlnaW5hbCkvU2lyYWkgKDEwODBwIEhEKS9Nb3ZpZXNkYS5Nb2JpIC0gU2lyYWkgMjAyNSBPcmlnaW5hbCAxMDgwcCBIRCAoMi40IEdCKS5tcDQ=", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.haus_-_Sirai_2025_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_Tam__Mal__Kan_-_DD5.1_-_192Kbps__AAC_-_6GB_-_ESub.mkv?token=feddc63949aef22677b23e592324a712&exp=1779990488", className: "K4" }
    ],
    watchUrl: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTg2ZjYyMzQ4MWE3YTA2MjU2N2RkNWZjMTQ0MTQxNjU4JmV4cD0xNzc5OTM3MTE4JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvU2lyYWkgKDIwMjUpL1NpcmFpIChPcmlnaW5hbCkvU2lyYWkgKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBTaXJhaSAyMDI1IE9yaWdpbmFsIDcyMHAgSEQubXA0&stream=1"
  },
  {
    title: "Tere Ishk Mein (2025)",
    image: "https://imgs.search.brave.com/UHu2tSo3XljhogE1xJsOPbtwINxzb40YQQDrTlkyUoM/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL00v/TVY1Qk9HUmpMek0x/Wm1VdE1qazBZaTAw/TnpBMExUazNaV1l0/WldNM01XWTNNMkV3/TWpCaFhrRXlYa0Zx/Y0djQC5qcGc",
    movieName: "Tere Ishk Mein (2025)",
    director: "Aanand L. Rai",
    starring: "Dhanush, Kriti Sanon",
    genres: ["Drama", "Romantic"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.1/10",
    lastUpdated: "23 January 2026",
    links: [
      { label: "Download 360p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPWFmOGQ1NDNkZTdjMWRiYTRmNTU1NGMzM2QxM2RjYWUzJmV4cD0xNzc5ODU0MzI0JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvVGVyZSBJc2hrIE1laW4gKDIwMjUpL1RlcmUgSXNoayBNZWluIChPcmlnaW5hbCkvVGVyZSBJc2hrIE1laW4gKDM2MHAgSEQpL01vdmllc2RhLk1vYmkgLSBUZXJlIElzaGsgTWVpbiAyMDI1IE9yaWdpbmFsIDM2MHAgSEQubXA0", className: "p480" },
      { label: "Download 720p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTczZTY0ZmNhMWU0ZGE0NmFiMjBmZjY2NzQ4Zjk1MmRlJmV4cD0xNzc5ODU0MzQ5JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvVGVyZSBJc2hrIE1laW4gKDIwMjUpL1RlcmUgSXNoayBNZWluIChPcmlnaW5hbCkvVGVyZSBJc2hrIE1laW4gKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBUZXJlIElzaGsgTWVpbiAyMDI1IE9yaWdpbmFsIDcyMHAgSEQubXA0", className: "p720" },
      { label: "Download 1080p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTAzYzQyNzY5YzY2ZDY4YjQ3ODg3MDM0MzNiZTdkZTA3JmV4cD0xNzc5ODU0MzY5JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvVGVyZSBJc2hrIE1laW4gKDIwMjUpL1RlcmUgSXNoayBNZWluIChPcmlnaW5hbCkvVGVyZSBJc2hrIE1laW4gKDEwODBwIEhEKS9Nb3ZpZXNkYS5Nb2JpIC0gVGVyZSBJc2hrIE1laW4gMjAyNSBPcmlnaW5hbCAxMDgwcCBIRCAoMy4wIEdCKS5tcDQ=", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.haus_-_Tere_Ishk_Mein_2025_TRUE_WEB-DL_-_1080p_-_AVC_-_Tam__Tel__Hin_-_DD5.1_-_640Kbps__AAC_-_8.2GB_-_ESub.mkv?token=a01b08898745b69feb37b9190e96f58b&exp=1779990588", className: "K4" }
    ],
    watchUrl: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPWZhODg0Y2NkM2VlNzA0NjMyZDEzODA3MzkxOTI2OWRlJmV4cD0xNzc5OTM3MTc2JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvVGVyZSBJc2hrIE1laW4gKDIwMjUpL1RlcmUgSXNoayBNZWluIChPcmlnaW5hbCkvVGVyZSBJc2hrIE1laW4gKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBUZXJlIElzaGsgTWVpbiAyMDI1IE9yaWdpbmFsIDcyMHAgSEQubXA0&stream=1"
  },
  {
    title: "Mark (2025)",
    image: "https://imgs.search.brave.com/g6fhC4a6kClIHO0KM1v6vMiKehcp1l6DI-iQYbvxI1A/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL01hcmstR2Fs/bGVyeS0zOTMyM2Ix/MC04OTY5LTExZjAt/OGUzMS1kZDUzMDFm/N2E2YzIuanBnP2lt/PVJlc2l6ZSx3aWR0/aD0zMjA",
    movieName: "Mark (2025)",
    director: "Vijay Kartikeyaa",
    starring: "Kiccha Sudeep, Naveen Chandra, Yogi Babu",
    genres: ["Action", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.7/10",
    lastUpdated: "23 January 2026",
    links: [
      { label: "Download 360p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTc5MjI0YTk0NjY3ZjljN2E5YTljODhlOTM3ZDZmMGNmJmV4cD0xNzc5ODU0NTY2JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvTWFyayAoMjAyNSkvTWFyayAoT3JpZ2luYWwpL01hcmsgKDM2MHAgSEQpL01vdmllc2RhLk1vYmkgLSBNYXJrIDIwMjUgT3JpZ2luYWwgMzYwcCBIRC5tcDQ=", className: "p480" },
      { label: "Download 720p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTZkZmQ2MGI1NmQxMTBiYmRmMWJiNmM1ODlkNmNjZTc0JmV4cD0xNzc5ODU0NTg2JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvTWFyayAoMjAyNSkvTWFyayAoT3JpZ2luYWwpL01hcmsgKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBNYXJrIDIwMjUgT3JpZ2luYWwgNzIwcCBIRC5tcDQ=", className: "p720" },
      { label: "Download 1080p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTc1MGFhZjY0Y2FkZDUyYjYzMmVkNjk5ZmZhOTA5YjM3JmV4cD0xNzc5ODU0NjA2JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvTWFyayAoMjAyNSkvTWFyayAoT3JpZ2luYWwpL01hcmsgKDEwODBwIEhEKS9Nb3ZpZXNkYS5Nb2JpIC0gTWFyayAyMDI1IE9yaWdpbmFsIDEwODBwIEhFICgyLjcgR0IpLm1wNA==", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.haus_-_Mark_2026_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_Tam__Tel__Mal__Kan_-_DD5.1_-_192Kbps__AAC_-_8.5GB_-_ESub.mkv?token=194c5994f5ec5d927a02e4a5c69922b8&exp=1779990662", className: "K4" }
    ],
    watchUrl: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTRmOWFjYmFjOTdmN2ZlMjdkOGRhMDUzNWNjMWE4ZWNiJmV4cD0xNzc5OTM3MjI5JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvTWFyayAoMjAyNSkvTWFyayAoT3JpZ2luYWwpL01hcmsgKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBNYXJrIDIwMjUgT3JpZ2luYWwgNzIwcCBIRC5tcDQ=&stream=1"
  },
  {
    title: "Galatta Family (2025)",
    image: "https://imgs.search.brave.com/hsEuVdliBeHZcwPuUJgFFf7BG7Ip0lvvyYHm4X2XlrM/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL2dhbGxlcnkl/MjAoNCktYmE1ZGY5/MTAtZDAyYS0xMWYw/LWI5YzktNjFmMDk4/MDdiMDNkLmpwZz9p/bT1SZXNpemUsd2lk/dGg9MzIw",
    movieName: "Galatta Family (2025)",
    director: "A. Sarkunam",
    starring: "Vemal, Anicka Vikhraman, Thambi Ramaiah",
    genres: ["Comedy", "Drama"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.1/10",
    lastUpdated: "25 April 2026",
    links: [
      { label: "Download 360p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Galatta_Family_2025_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Galatta_Family_2025_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s11.cdnserver02.xyz/Moviesda.Mobi_-_Galatta_Family_2025_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" }
    ],
    watchUrl: "https://s25.cdnserver03.xyz/Moviesda.Mobi_-_Galatta_Family_2025_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Prathichaya (2026)",
    image: "https://imgs.search.brave.com/_XAK1_FvKIikgytRTnxv84qxApzSTnoNzRywLMDmJUo/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZS50bWRiLm9yZy90/L3AvdzYwMF9hbmRf/aDkwMF9iZXN0djIv/bzY5WUtGZDVXU3dY/MWY5UEJHNDdRZmNH/elg0LmpwZw",
    movieName: "Prathichaya (2026)",
    director: "Unnikrishnan B.",
    starring: "Nivin Pauly, Sharafudheen, Balachandra Menon",
    genres: ["Drama", "Political", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.8/10",
    lastUpdated: "24 April 2026",
    links: [
      { label: "Download 360p", url: "https://s32.cdnserver04.xyz/Prathichaya_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s14.cdnserver02.xyz/Prathichaya_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s31.cdnserver04.xyz/Prathichaya_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.LTD_-_Prathichaya_2026_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_Tam__Tel__Hin__Mal__Kan_-_DD5.1_-_192Kbps__AAC_-_8.2GB_-_ESub.mkv?token=d823ef965eabb991c1e1c05b1963dfdb&exp=1779990772", className: "K4" }
    ],
    watchUrl: "https://s13.cdnserver02.xyz/Prathichaya_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Happy Raj (2026)",
    image: "https://imgs.search.brave.com/pHkWy6VTUkic21cyvZHlnS79dOMc1oHi-Radc9YaLis/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9hc3Nl/dHMtaW4uYm1zY2Ru/LmNvbS9pZWRiL21v/dmllcy9pbWFnZXMv/bW9iaWxlL3RodW1i/bmFpbC94bGFyZ2Uv/aGFwcHktcmFqLWV0/MDA0OTAwOTctMTc3/MjYxMjQ2Mi5qcGc",
    movieName: "Happy Raj (2026)",
    director: "Maria Raja Elanchezian",
    starring: "G. V. Prakash Kumar, Abbas, Sri Gouri Priya",
    genres: ["Comedy", "Drama", "Romantic"],
    quality: "Original HD",
    language: "Tamil",
    rating: "6.9/10",
    lastUpdated: "24 April 2026",
    links: [
      { label: "Download 360p", url: "https://s05.cdnserver01.xyz/Moviesda.Mobi_-_Happy_Raj_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s14.cdnserver02.xyz/Moviesda.Mobi_-_Happy_Raj_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s13.cdnserver02.xyz/Moviesda.Mobi_-_Happy_Raj_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.ltd_-_Happy_Raj_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_Tam__Tel_-_DD5.1_-_640Kbps__AAC_-_5.8GB_-_ESub.mkv?token=b08ba937dec3075626134ce41680d475&exp=1779990842", className: "K4" }
    ],
    watchUrl: "https://s31.cdnserver04.xyz/Moviesda.Mobi_-_Happy_Raj_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Shamitabh (2015)",
    image: "https://imgs.search.brave.com/nJtLNdEby3_iD5XIsIeaASlmYgPq4_bTxTQqF7s9f-A/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9zdGF0/aWMuZGlnaXQuaW4v/T1RUL2ltYWdlcy9z/aGFtaXRhYmgtNjA1/YjNmNDFiODc3NzVl/NzYyODQwYWIyLmpw/Zz90cj13LTYwMA",
    movieName: "Shamitabh (2015)",
    director: "R. Balki",
    starring: "Dhanush, Amitabh Bachchan, Rekha",
    genres: ["Drama"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.1/10",
    lastUpdated: "18 April 2026",
    links: [
      { label: "Download 360p", url: "https://cdn.uptodl.ch/download.php?server=cdn4&hash=1433c26ef42572311f3e0b04458040e8&exp=1779704097&path=Tamil%20HD%20Mobile%20Movies/Shamitabh%20(2015)/Shamitabh%20(Original)/Shamitabh%20(360p%20HD)/Moviesda.Mobi%20-%20Shamitabh%202015%20Original%20360p%20HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://cdn.uptodl.ch/download.php?server=cdn4&hash=2d14a9fcc7ab9b3a7e9ea075886205de&exp=1779704241&path=Tamil%20HD%20Mobile%20Movies/Shamitabh%20(2015)/Shamitabh%20(Original)/Shamitabh%20(720p%20HD)/Moviesda.Mobi%20-%20Shamitabh%202015%20Original%20720p%20HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://cdn.uptodl.ch/download.php?server=cdn4&hash=aa2fd8e7ad9041fbe12d0b9e5e155248&exp=1779704278&path=Tamil%20HD%20Mobile%20Movies/Shamitabh%20(2015)/Shamitabh%20(Original)/Shamitabh%20(1080p%20HD)/Moviesda.Mobi%20-%20Shamitabh%202015%20Original%201080p%20HD%20(2.7%20GB).mp4", className: "p1080" }
    ],
    watchUrl: "https://cdn.uptodl.ch/download.php?server=cdn4&hash=ba85f9b201056f04024914a76cdbb1b6&exp=1779937449&path=Tamil%20HD%20Mobile%20Movies/Shamitabh%20(2015)/Shamitabh%20(Original)/Shamitabh%20(720p%20HD)/Moviesda.Mobi%20-%20Shamitabh%202015%20Original%20720p%20HD.mp4&stream=1"
  },
  {
    title: "Mustafa Mustafa (2026)",
    image: "https://imgs.search.brave.com/mNkfnDv9LIsuDErSCErdBNNbyqvK8ck3Km_jHVcPp6o/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL111c3RhZmEt/TXVzdGFmYS0tcG9z/dGVyLTU3MWMwZTEw/LTE2YzktMTFmMS1i/MTRhLTZmMmFmODVl/MmZkOC5qcGc_aW09/UmVzaXplLHdpZHRo/PTMyMA",
    movieName: "Mustafa Mustafa (2026)",
    director: "Praveen Saravanan",
    starring: "Sathish Muthukrishnan, Suresh Ravi, Monica Chinnakotla",
    genres: ["Comedy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "6.6/10",
    lastUpdated: "17 April 2026",
    links: [
      { label: "Download 360p", url: "https://s31.cdnserver04.xyz/Moviesda.Mobi_-_Mustafa_Mustafa_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s02.cdnserver01.xyz/Moviesda.Mobi_-_Mustafa_Mustafa_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_Mustafa_Mustafa_2026_Original_1080p_HD_(3.6_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.frl_-_Mustafa_Mustafa_2026_Tamil_TRUE_WEB-DL_-_1080p_-_AVC_-_DD2.0_-_224Kbps__AAC_-_6.3GB_-_ESub.mkv?token=33de1cb68683785590ae81ebf249a23a&exp=1779990943", className: "K4" }
    ],
    watchUrl: "https://s24.cdnserver03.xyz/Moviesda.Mobi_-_Mustafa_Mustafa_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Youth (2026)",
    image: "https://imgs.search.brave.com/ki52FTSO9MiGhWf1z8qlxAwMsbcW8u4hTEqddRpKNRU/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL1lvdXRoX0dh/bGxlcnktNjM5ZTg1/MTAtMDVhMi0xMWYx/LWFjMWYtMzM5MWRi/ZjA0NWU1LmpwZz9p/bT1SZXNpemUsd2lk/dGg9MzIw",
    movieName: "Youth (2026)",
    director: "Ken Karunas",
    starring: "Ken Karunas, Anishma Anilkumar, Devadarshini",
    genres: ["Comedy", "Drama", "Romantic"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.3/10",
    lastUpdated: "16 April 2026",
    links: [
      { label: "Download 360p", url: "https://s22.cdnserver03.xyz/Moviesda.Mobi_-_Youth_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s31.cdnserver04.xyz/Moviesda.Mobi_-_Youth_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Youth_2026_Original_1080p_HD_(3.6_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.frl_-_Youth_2026_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_Tam__Tel__Hin__Mal__Kan_-_DD5.1_-_640Kbps__AAC_-_20GB_-_ESub.mkv?token=ac4096c09036d1a3c13e8ae8ba8025b5&exp=1779991029", className: "K4" }
    ],
    watchUrl: "https://s35.cdnserver04.xyz/Moviesda.Mobi_-_Youth_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Suyodhana (2026)",
    image: "https://imgs.search.brave.com/N3mLYrK6WwM5XPoN3_9fC_4-UkqArlj2F4egOZJ8j00/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9wcmV2/aWV3LnJlZGQuaXQv/YXlvLXRoaXMtZmls/bXMtcHJldHR5LWdv/b2QtZm9yLWl0cy1s/b3ctYnVkZ2V0LXN1/eW9kaGFuYS12MC1i/ZHI0YXRudmMzd2cx/LmpwZWc_d2lkdGg9/NjQwJmNyb3A9c21h/cnQmYXV0bz13ZWJw/JnM9ZTkyMTMzOTUz/NTU4NDhhZGNhYzEz/NGYzZDM4NDQwNmFl/YjA3MjM3NQ",
    movieName: "Suyodhana (2026)",
    director: "Y.S. Madav Reddy",
    starring: "Priyadarshi Pulikonda, Drishika Chandar, Saikumar Pudipeddi",
    genres: ["Drama", "Mystery", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.1/10",
    lastUpdated: "17 April 2026",
    links: [
      { label: "Download 360p", url: "https://s03.cdnserver01.xyz/Moviesda.Mobi_-_Suyodhana_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s02.cdnserver01.xyz/Moviesda.Mobi_-_Suyodhana_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s33.cdnserver04.xyz/Moviesda.Mobi_-_Suyodhana_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.frl_-_Suyodhana_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_Tam__Tel_-_DD5.1_-_640Kbps__AAC_-_5.2GB_-_ESub.mkv?token=d7ed49bcf4c37146c3f3dc2a5ff68a5e&exp=1779996898", className: "K4" }
    ],
    watchUrl: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_Suyodhana_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Kaa The Forest (2026)",
    image: "https://imgs.search.brave.com/TnPTMcZAdboAKueNZgZL0T8UFy1dzXDccW3T8Kbw6mU/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL19LYWEtLS1U/aGUtRm9yZXN0LTY3/NjExOTUwLTAwMjYt/MTFmMS1kMmY0LWU1/ODI4MGNkMjMyZi5q/cGc_aW09UmVzaXpl/LHdpZHRoPTMyMA",
    movieName: "Kaa The Forest (2026)",
    director: "Nanjil Nagarajan",
    starring: "Andrea Jeremiah, Salim Ghouse, Marimuthu",
    genres: ["Adventure", "Crime", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.5/10",
    lastUpdated: "17 April 2026",
    links: [
      { label: "Download 360p", url: "https://s01.cdnserver01.xyz/Moviesda.Mobi_-_Kaa_The_Forest_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s21.cdnserver03.xyz/Moviesda.Mobi_-_Kaa_The_Forest_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_Kaa_The_Forest_2026_Original_1080p_HD_(2.3_GB).mp4", className: "p1080" }
    ],
    watchUrl: "https://s13.cdnserver02.xyz/Moviesda.Mobi_-_Kaa_The_Forest_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Second Case of Seetharam (2026)",
    image: "https://imgs.search.brave.com/od6NyKwYfwmllIHM29M7jtce8Ya48Ayj7o3Oo9xyTXs/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMuZGluYW1hbGFy/bW9iaWxlL2Npbmkv/Q2luZUdhbGxlcnkv/Vk1fMjAyNjA0MTAx/MzE2MDYwMDAw/MDAuanBn", /* note fallback link */
    movieName: "Second Case of Seetharam (2026)",
    director: "Devi Prasad Shetty",
    starring: "Vijay Raghavendra, Gopal Krishna Deshpande, Usha Bhandari",
    genres: ["Crime", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.9/10",
    lastUpdated: "17 April 2026",
    links: [
      { label: "Download 360p", url: "https://s05.cdnserver01.xyz/Moviesda.Mobi_-_Second_Case_of_Seetharam_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s21.cdnserver03.xyz/Moviesda.Mobi_-_Second_Case_of_Seetharam_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_Second_Case_of_Seetharam_2026_Original_1080p_HD_(3.0_GB).mp4", className: "p1080" }
    ],
    watchUrl: "https://s25.cdnserver03.xyz/Moviesda.Mobi_-_Second_Case_of_Seetharam_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Ustaad Bhagat Singh (2026)",
    image: "https://imgs.search.brave.com/Rf42EyhUtvAIEvWuR3do_bG_bM2EiS87U8F_k8fivig/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL1VzdGFhZC1C/aGFnYXQtU2luZ2gt/M2JiNGZiNjAtZjEx/MS0xMWYwLWJjYTMt/MzE4OGE2ZTcyOTQ2/LmpwZz9pbT1SZXNp/emUsd2lkdGg9MzIw",
    movieName: "Ustaad Bhagat Singh (2026)",
    director: "Harish Shankar",
    starring: "Pawan Kalyan, Sree Leela, Raashi Khanna",
    genres: ["Action", "Comedy", "Drama"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.1/10",
    lastUpdated: "16 April 2026",
    links: [
      { label: "Download 360p", url: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_Ustaad_Bhagat_Singh_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_Ustaad_Bhagat_Singh_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_Ustaad_Bhagat_Singh_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.frl_-_Ustaad_Bhagat_Singh_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_Tamil__Telugu__Hindi__Malayalam__Kannada.mkv?token=2dc35eec53870e20391cfd72ebe51450&exp=1779997117", className: "K4" }
    ],
    watchUrl: "https://s32.cdnserver04.xyz/Moviesda.Mobi_-_Ustaad_Bhagat_Singh_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Toaster (2026)",
    image: "https://imgs.search.brave.com/2KtmzjdKSHMFtaPnBgiTb_fFZ4AyQyQwMal9R7EcTes/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZS50bWRiLm9yZy90/L3AvdzYwMF9hbmRf/aDkwMF9iZXN0djIv/YlFoQ3NjTDd5Vjhx/dG9kMm1EcEphNlMy/OFZKLmpwZw",
    movieName: "Toaster (2026)",
    director: "Vivek Daschaudhary",
    starring: "Rajkummar Rao, Sanya Malhotra, Abhishek Banerjee",
    genres: ["Comedy", "Drama"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.8/10",
    lastUpdated: "15 April 2026",
    links: [
      { label: "Download 360p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Toaster_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_Toaster_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s03.cdnserver01.xyz/Moviesda.Mobi_-_Toaster_2026_Original_1080p_HD_(3.2_GB).mp4", className: "p1080" }
    ],
    watchUrl: "https://s32.cdnserver04.xyz/Moviesda.Mobi_-_Toaster_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Sarkar (2018)",
    image: "https://imgs.search.brave.com/SF-83eIwqMMK_N1ET98f86sK61z5epBXhwxCv2gx-v8/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9saXZl/LnN0YXRpY2ZsaWNr/ci5jb20vMTkyOS80/NDcwOTI2MDU0NF8z/MGNiZWJjYmQ3Lmpw/Zw",
    movieName: "Sarkar (2018)",
    director: "A.R. Murugadoss",
    starring: "Vijay, Keerthy Suresh, Varalaxmi Sarathkumar",
    genres: ["Action", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.4/10",
    lastUpdated: "02 April 2026",
    links: [
      { label: "Download 360p", url: "https://cdn.uptodl.ch/download.php?server=cdn4&hash=7e57c68eb547c1deada31ba51bb7c717&exp=1779708216&path=Tamil%20HD%20Mobile%20Movies/Sarkar%20(2018)/Sarkar%20(Original)/Sarkar%20(360p%20HD)/Moviesda.Mobi%20-%20Sarkar%202018%20Original%20360p%20HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://cdn.uptodl.ch/download.php?server=cdn4&hash=15f6538247ba240a1d987d6d40d59ead&exp=1779708246&path=Tamil%20HD%20Mobile%20Movies/Sarkar%20(2018)/Sarkar%20(Original)/Sarkar%20(720p%20HD)/Moviesda.Mobi%20-%20Sarkar%202018%20Original%20720p%20HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://cdn.uptodl.ch/download.php?server=cdn4&hash=2e9928ffa99f465ca8a0a52db571e066&exp=1779708419&path=Tamil%20HD%20Mobile%20Movies/Sarkar%20(2018)/Sarkar%20(Original)/Sarkar%20(1080p%20HD)/Moviesda.Mobi%20-%20Sarkar%202018%20Original%201080p%20HD%20(3.5%20GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.cymru_-_Sarkar_2018_Tamil_TRUE_WEB-DL_-_4K_SDR_-_2160p_HQ_-_HEVC_-_DD5.1_ATMOS_-_448Kbps__AAC_2.0_-_15GB_-_ESub.mkv?token=e24ae49004d6ce1e8b40620914ecd1d7&exp=1779997205", className: "K4" }
    ],
    watchUrl: "https://cdn.uptodl.ch/download.php?server=cdn4&hash=b30d10afdc03e8d8ddc015f44f33f181&exp=1779997907&path=Tamil%20HD%20Mobile%20Movies/Sarkar%20(2018)/Sarkar%20(Original)/Sarkar%20(1080p%20HD)/Moviesda.Mobi%20-%20Sarkar%202018%20Original%201080p%20HD%20(3.5%20GB).mp4&stream=1"
  },
  {
    title: "Sambavam Adhyayam Onnu (2026)",
    image: "https://imgs.search.brave.com/FROycpUvLpenSjNUXcByf-UsnT4VnQ7-64cu3T8OBoc/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9kM3Jx/eXM5YTZ3bTluby5j/bG91ZGZyb250Lm5l/dC9pbWFnZXMvbW92/aWVzL3Bvc3Rlci9I/RDlMTWE3VUgxVmRY/TGdUb0pBbWE5MUEw/aExqZGd4Rl8zMDB4/NDQyLmpwZz90PTE3/NzI0NDI5NjM",
    movieName: "Sambavam Adhyayam Onnu (2026)",
    director: "Jithu Satheesan Mangalathu",
    starring: "Askar Ali, Vineeth Kumar, Sidharth Bharathan",
    genres: ["Mystery", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.5/10",
    lastUpdated: "15 April 2026",
    links: [
      { label: "Download 360p", url: "https://s25.cdnserver03.xyz/Sambavam_Adhyayam_Onnu_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s12.cdnserver02.xyz/Sambavam_Adhyayam_Onnu_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s23.cdnserver03.xyz/Sambavam_Adhyayam_Onnu_2026_Original_1080p_HD_(3.3_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.frl_-_Sambavam_Adhyayam_Onnu_2026_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_Tam__Tel__Hin__Mal__Kan_-_DD5.1_-_192Kbps__AAC_-_10GB_-_ESub.mkv?token=714829090960d82ac6bbd23d45a8e94e&exp=1779997276", className: "K4" }
    ],
    watchUrl: "https://s23.cdnserver03.xyz/Sambavam_Adhyayam_Onnu_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Her (2026)",
    image: "https://imgs.search.brave.com/2McSt3W9JXLo1JZ6DwGaKbh33fem7Issf4VhBwlJ63Y/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9zMy5h/cC1zb3V0aC0xLmFt/YXpvbmF3cy5jb20v/bWVkaWEudGhlc291/dGhmaXJzdC5jb20v/d3AtY29udGVudC91/cGxvYWRzLzIwMjQv/MTEvQS1wb3N0ZXIt/b2YtdGhlLWZpbG0t/SGVyLTEuanBn",
    movieName: "Her (2026)",
    director: "Lijin Jose",
    starring: "Urvashi, Parvathy Thiruvothu, Aishwarya Rajesh",
    genres: ["Anthology", "Drama"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.1/10",
    lastUpdated: "13 April 2026",
    links: [
      { label: "Download 360p", url: "https://s22.cdnserver03.xyz/Her_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s35.cdnserver04.xyz/Her_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s12.cdnserver02.xyz/Her_2026_Original_1080p_HD_(1.7_GB).mp4", className: "p1080" }
    ],
    watchUrl: "https://s35.cdnserver04.xyz/Her_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Thaai Kizhavi (2026)",
    image: "https://imgs.search.brave.com/CXAtoY8iuB34IkUj5Cl_S5VJBdDsHLcVyzGepoGQJXE/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL00v/TVY1QlpUQXhZemRs/WVRJdFlqWTFNaTAw/WXpaakxUZzJOekl0/TWpZM1pHTTRNVE0x/WkdOa1hrRXlYa0Zx/Y0djQC5qcGc",
    movieName: "Thaai Kizhavi (2026)",
    director: "Sivakumar Murugesan",
    starring: "Raadhika Sarathkumar, Singam Puli, Aruldoss",
    genres: ["Comedy", "Drama"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.7/10",
    lastUpdated: "10 April 2026",
    links: [
      { label: "Download 360p", url: "https://s22.cdnserver03.xyz/Moviesda.Mobi_-_Thaai_Kizhavi_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s25.cdnserver03.xyz/Moviesda.Mobi_-_Thaai_Kizhavi_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s33.cdnserver04.xyz/Moviesda.Mobi_-_Thaai_Kizhavi_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.gripe_-_Thaai_Kizhavi_2026_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_Tam__Tel__Hin__Mal__Kan_-_DD5.1_-_192Kbps__AAC_-_13GB_-_ESub.mkv?token=e031ffaadd50bf5a182e6ed781e900c7&exp=1779997354", className: "K4" }
    ],
    watchUrl: "https://s12.cdnserver02.xyz/Moviesda.Mobi_-_Thaai_Kizhavi_2026_Original_720p_HD_(950_MB).mp4?stream=1"
  },
  {
    title: "Kadhal Kadhai Sollava (2026)",
    image: "https://imgs.search.brave.com/ne-QQbhEsTQhfQZfhcdGvu7S0ePy1W9tBYETr3obvP8/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9hc3Nl/dHMtaW4uYm1zY2Ru/LmNvbS9pZWRiL21v/dmllcy9pbWFnZXMv/bW9iaWxlL3RodW1i/bmFpbC94bGFyZ2Uv/a2FkaGFsLWthZGhh/aS1zb2xsYXZhLWV0/MDA0ODQ4NTEtMTc3/MDIwOTE4MC5qcGc",
    movieName: "Kadhal Kadhai Sollava (2026)",
    director: "Sanil Kalathil",
    starring: "Vijay Sethupathi, Jayaram Subramaniam, Athmiya Rajan",
    genres: ["Drama", "Romantic"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.3/10",
    lastUpdated: "10 April 2026",
    links: [
      { label: "Download 360p", url: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_Kadhal_Kadhai_Sollava_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s32.cdnserver04.xyz/Moviesda.Mobi_-_Kadhal_Kadhai_Sollava_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s12.cdnserver02.xyz/Moviesda.Mobi_-_Kadhal_Kadhai_Sollava_2026_Original_1080p_HD_(3.6_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.gripe_-_Kadhal_Kadhai_Sollava_2026_Tamil_TRUE_WEB-DL_-_1080p_-_AVC_-_DD2.0_-_224Kbps__AAC_2.0_-_4.3GB_-_ESub.mkv?token=a912e692118d455cc3ee326d05a7f7ce&exp=1779997413", className: "K4" }
    ],
    watchUrl: "https://s12.cdnserver02.xyz/Moviesda.Mobi_-_Kadhal_Kadhai_Sollava_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Kadhal Reset Repeat (2026)",
    image: "https://imgs.search.brave.com/bBUeA0YqBC3Vhj3Ll8jAYjtP0iG80UwDjh-5QID0vuQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMuZGluYW1hbGFy/bW9iaWxlL2Npbmkv/Q2luZUdhbGxlcnkv/Vk1fMjAyNjAzMDcx/MTU4MjkwMDAw/MDAuanBn",
    movieName: "Kadhal Reset Repeat (2026)",
    director: "A. L. Vijay",
    starring: "Arjun Ashokan, Madumkesh Prem, Jiyaa Shankar",
    genres: ["Comedy", "Drama", "Romantic"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.2/10",
    lastUpdated: "08 April 2026",
    links: [
      { label: "Download 360p", url: "https://s25.cdnserver03.xyz/Moviesda.Mobi_-_Kadhal_Reset_Repeat_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s02.cdnserver01.xyz/Moviesda.Mobi_-_Kadhal_Reset_Repeat_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s11.cdnserver02.xyz/Moviesda.Mobi_-_Kadhal_Reset_Repeat_2026_Original_1080p_HD_(3.6_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.gripe_-_Kadhal_Reset_Repeat_2026_Tamil_TRUE_WEB-DL_-_1080p_-_AVC_-_DD5.1_-_640Kbps__AAC_-_8.6GB_-_ESub.mkv?token=99605da28c9c81855c7907c411c58c48&exp=1779997485", className: "K4" }
    ],
    watchUrl: "https://s24.cdnserver03.xyz/Moviesda.Mobi_-_Kadhal_Reset_Repeat_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Seetha Payanam (2026)",
    image: "https://imgs.search.brave.com/sVAzLTwb4VQLP03g-Uq_IXxEEfYzRA4oN01o5vEMJIA/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9zdW5k/LWltYWdlcy5zdW5u/eHQuY29tLzI0NjQ1/NC8yNTB4Mzc1X1Nl/ZXRoYVBheWFuYW1U/YW1pbF8yNDY0NTRf/MGFiYzg0MGQtZDA2/Yi00Y2NhLWExZWIt/NDFhMTNlZDU2YWE4/LmpwZw",
    movieName: "Seetha Payanam (2026)",
    director: "Arjun Sarja",
    starring: "Niranjan Sudhindra, Aishwarya Arjun, Dhruva Sarja",
    genres: ["Drama", "Family"],
    quality: "Original HD",
    language: "Tamil",
    rating: "6.3/10",
    lastUpdated: "19 March 2026",
    links: [
      { label: "Download 360p", url: "https://dl3.biggshare.xyz/Moviesda.Mobi_-_Seetha_Payanam_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s10.hotshare.link/Moviesda.Mobi_-_Seetha_Payanam_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s07.hotshare.link/Moviesda.Mobi_-_Seetha_Payanam_2026_Original_1080p_HD__3.5_GB_.mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.rodeo_-_Seetha_Payanam_2026_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_Tam__Tel__Mal__Kan_-_DD5.1_-_192Kbps__AAC_-_10GB_-_ESub.mkv?token=cc4e2cf2b04c677189214dadcaf12a8e&exp=1779997550", className: "K4" }
    ],
    watchUrl: "https://s02.hotshare.link/Moviesda.Mobi_-_Seetha_Payanam_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Jana Nayagan Audio Launch (2026)",
    image: "https://imgs.search.brave.com/PmvpV2rPjnC24asklNu8aEDre6acctmDXzmTH04z7hc/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL00v/TVY1Qk9URTFNMlpr/WmpZdE56RXhOaTAw/TVRRd0xUZzNaRFl0/WVRBM1ltUXlNRGd5/WmpVNFhrRXlYa0Zx/Y0djQC5qcGc",
    movieName: "Jana Nayagan Audio Launch (2026)",
    director: "H. Vinoth",
    starring: "Vijay, Bobby Deol, Pooja Hegde",
    genres: ["Action", "Drama", "Political"],
    quality: "Original HD",
    language: "Tamil",
    rating: "10/10",
    lastUpdated: "04 January 2026",
    links: [
      { label: "Download 480p", url: "https://dl9.biggshare.xyz/Moviesda.Mobi_-_Jana_Nayagan_Audio_Launch_2026_HDRip_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s01.hotshare.link/Moviesda.Mobi_-_Jana_Nayagan_Audio_Launch_2026_HDRip_720p_HD.mp4", className: "p720" }
    ],
    watchUrl: "https://s09.hotshare.link/Moviesda.Mobi_-_Jana_Nayagan_Audio_Launch_2026_HDRip_720p_HD.mp4?stream=1"
  },
  {
    title: "Parasakthi Audio Launch (2026)",
    image: "https://imgs.search.brave.com/h7NZ5a0U7gl2SdouE6FwIYRJt64P_2fjo04FkrfmPug/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL1BhcmFhMS1t/aW4tMjNjY2RjNjAt/ZWJiZC0xMWYwLTk0/MGYtZjFkODZjMjRh/M2MxLmpwZz9pbT1S/ZXNpemUsd2lkdGg9/MzIw",
    movieName: "Parasakthi Audio Launch (2026)",
    director: "Sudha Kongara Prasad",
    starring: "Sivakarthikeyan, Sree Leela, Jayam Ravi, Atharvaa",
    genres: ["Action", "Drama", "Period", "Political"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.9/10",
    lastUpdated: "07 February 2026",
    links: [
      { label: "Download 360p", url: "https://dl7.biggshare.xyz/Moviesda.Mobi_-_Parasakthi_Audio_Launch_2026_Full_Show_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://dl5.biggshare.xyz/Moviesda.Mobi_-_Parasakthi_Audio_Launch_2026_Full_Show_720p_HD.mp4", className: "p720" }
    ],
    watchUrl: "https://dl5.biggshare.xyz/Moviesda.Mobi_-_Parasakthi_Audio_Launch_2026_Full_Show_720p_HD.mp4?stream=1"
  },
  {
    title: "Harry Potter and The Deathly Hallows Part 2 (2011)",
    image: "https://imgs.search.brave.com/PfLNj_9_xW8-XTnAUpICNrIjbxm6RljWoAoctjOgNo8/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tZWRp/YS5oYXJyeXBvdHRl/cmZhbnpvbmUuY29t/L2RlYXRobHktaGFs/bG93cy1wYXJ0LTIt/aGFycnktcG9zdGVy/LmpwZw",
    movieName: "Harry Potter and The Deathly Hallows Part 2 (2011)",
    director: "David Yates",
    starring: "Daniel Radcliffe, Emma Watson, Rupert Grint",
    genres: ["Adventure", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.1/10",
    lastUpdated: "16 January 2026",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD0xMmUzMjMwMDBjMDA2N2YxYzk0MjcxOWUzNWQyYTg5NiZleHA9MTc3OTgxNDE4NCZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMiAoMjAxMSkvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMiAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDIgKDM2MHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDIgMjAxMSBPcmlnaW5hbCAzNjBwIEhELm1wNA==", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD1kMGRiYmVhMzIxOTNjYmFlMDUwOGM1ZTkwYTU0YzYxNiZleHA9MTc3OTgxNDIxMCZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMiAoMjAxMSkvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMiAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDIgKDcyMHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDIgMjAxMSBPcmlnaW5hbCA3MjBwIEhELm1wNA==", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD0wM2Y5NDNiMjM4MzM4NWQ4N2Y1NGM2MjAzZTZmZjZhZCZleHA9MTc3OTgxNDIyOSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMiAoMjAxMSkvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMiAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDIgKDEwODBwIEhEKS9IYXJyeSBQb3R0ZXIgYW5kIFRoZSBEZWF0aGx5IEhhbGxvd3MgUGFydCAyIDIwMTEgT3JpZ2luYWwgMTA4MHAgSEQubXA0", className: "p1080" }
    ]
  },
  {
    title: "Harry Potter and The Deathly Hallows Part 1 (2010)",
    image: "https://imgs.search.brave.com/s5MOYLPAujJpyTkKW249qeRSPiXikkMFXtJqAH6xe7Y/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9zdGF0/aWMud2lraWEubm9j/b29raWUubmV0L2hh/cnJ5cG90dGVyL2lt/YWdlcy85Lzk1L0hh/cnJ5X1BvdHRlcl9h/bmRfdGhlX0RlYXRo/bHlfSGFsbG93c19Q/YXJ0XzJfcHJvbW90/aW9uYWxfcG9zdGVy/LmpwZy9yZXZpc2lv/bi9sYXRlc3Qvc2Nh/bGUtdG8td2lkdGgt/ZG93bi8yNjc_Y2I9/MjAxMzA4MDMxNjQz/NDU",
    movieName: "Harry Potter and The Deathly Hallows Part 1 (2010)",
    director: "Lionel Wigram",
    starring: "Daniel Radcliffe, Emma Watson, Rupert Grint",
    genres: ["Adventure", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.7/10",
    lastUpdated: "16 January 2026",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD1kNDY3MTU2MmYyOGUyMjY0ZWY0ZjIyYjZiMjI2NDUwYSZleHA9MTc3OTgxMzk2OCZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMSAoMjAxMCkvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMSAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDEgKDM2MHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDEgMjAxMCBPcmlnaW5hbCAzNjBwIEhELm1wNA==", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD0xYWVkMTg0MjJiZGQxOWJiZjgzNzI0MjA1ZTZlNzI3NyZleHA9MTc3OTgxMzk4OSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMSAoMjAxMCkvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMSAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDEgKDcyMHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDEgMjAxMCBPcmlnaW5hbCA3MjBwIEhELm1wNA==", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD1lZDY2MDNjOGY1NTYyYzE0MDE4ZmIzZDYzN2IxNGE4OCZleHA9MTc3OTgxNDAxNyZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMSAoMjAxMCkvSGFycnkgUG90dGVyIGFuZCBUaGUgRGVhdGhseSBIYWxsb3dzIFBhcnQgMSAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIERlYXRobHkgSGFsbG93cyBQYXJ0IDEgKDEwODBwIEhEKS9IYXJyeSBQb3R0ZXIgYW5kIFRoZSBEZWF0aGx5IEhhbGxvd3MgUGFydCAxIDIwMTAgT3JpZ2luYWwgMTA4MHAgSEQubXA0", className: "p1080" }
    ]
  },
  {
    title: "Harry Potter and The Order of the Phoenix (2007)",
    image: "https://imgs.search.brave.com/WpqsB0u1tEkUxlU8R7jKm1Kk77Gpa9c8-ONN9M_mph4/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL00v/TVY1Qk9EZGhNV0ky/WXpjdFpETmxOeTAw/TVRjNExXSmpZbU10/TldVNFpHUTJaVE16/WWprelhrRXlYa0Zx/Y0djQC5qcGc",
    movieName: "Harry Potter and The Order of the Phoenix (2007)",
    director: "David Yates",
    starring: "Daniel Radcliffe, Rupert Grint, Emma Watson",
    genres: ["Adventure", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.7/10",
    lastUpdated: "07 January 2026",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD02NTIyMjRhZTE2NDBjYTcwNzFjNDk5Y2YzMzQwZmQyMyZleHA9MTc3OTgxMzc2MCZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgT3JkZXIgb2YgdGhlIFBob2VuaXggKDIwMDcpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIE9yZGVyIG9mIHRoZSBQaG9lbml4IChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCBUaGUgT3JkZXIgb2YgdGhlIFBob2VuaXggKDM2MHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIE9yZGVyIG9mIHRoZSBQaG9lbml4IDIwMDcgT3JpZ2luYWwgMzYwcCBIRC5tcDQ=", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD0xODc2YTAyYmIzMGQ5N2NiOTNkNWQxODJiMjFiOWY3MCZleHA9MTc3OTgxMzc4MyZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgT3JkZXIgb2YgdGhlIFBob2VuaXggKDIwMDcpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIE9yZGVyIG9mIHRoZSBQaG9lbml4IChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCBUaGUgT3JkZXIgb2YgdGhlIFBob2VuaXggKDcyMHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIE9yZGVyIG9mIHRoZSBQaG9lbml4IDIwMDcgT3JpZ2luYWwgNzIwcCBIRC5tcDQ=", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD01NTJjMTJkMDBiMTc0OWIyZjgwODUyMjZmMzFkYzU0NiZleHA9MTc3OTgxMzgwNyZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgT3JkZXIgb2YgdGhlIFBob2VuaXggKDIwMDcpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIE9yZGVyIG9mIHRoZSBQaG9lbml4IChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCBUaGUgT3JkZXIgb2YgdGhlIFBob2VuaXggKDEwODBwIEhEKS9IYXJyeSBQb3R0ZXIgYW5kIFRoZSBPcmRlciBvZiB0aGUgUGhvZW5peCAyMDA3IE9yaWdpbmFsIDEwODBwIEhELm1wNA==", className: "p1080" }
    ]
  },
  {
    title: "Harry Potter and The Half-Blood Prince (2009)",
    image: "https://imgs.search.brave.com/56Dfw2D6OnTZjs1u8QqHvjkjnNYyD9z36HjLd6wbIIg/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9ydWtt/aW5pbTIuZmxpeGNh/cnQuY29tL2ltYWdl/LzUzMC81MzAvam05/aGZndzAvbW92aWUv/Yi9uLzMvMjAxOC1k/dmQtd2FybmVyLWJy/b3MtZXhjZWwtaG9t/ZS12aWRlb3MtZW5n/bGlzaC1oYXJyeS1w/b3R0ZXItYW5kLW9yaWdpbmFsLWltYWY5Z2s2/enZrY3R1ZncuanBl/Zz9xPTkw",
    movieName: "Harry Potter and The Half-Blood Prince (2009)",
    director: "Lionel Wigram",
    starring: "Daniel Radcliffe, Rupert Grint, Emma Watson",
    genres: ["Adventure", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.7/10",
    lastUpdated: "07 January 2026",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD05YWRhNmY1ZGMyYzI4YzkyY2NjNWIyYzUwOGM1OGEwMiZleHA9MTc3OTgxMzU1NyZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgSGFsZi1CbG9vZCBQcmluY2UgKDIwMDkpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIEhhbGYtQmxvb2QgUHJpbmNlIChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCBUaGUgSGFsZi1CbG9vZCBQcmluY2UgKDM2MHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIEhhbGYtQmxvb2QgUHJpbmNlIDIwMDkgT3JpZ2luYWwgMzYwcCBIRC5tcDQ=", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD00MzgyMDVmMDA4ZDQ3NzVjMzc1ODE3OWQ5MDBiZGY2NyZleHA9MTc3OTgxMzU3NyZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgSGFsZi1CbG9vZCBQcmluY2UgKDIwMDkpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIEhhbGYtQmxvb2QgUHJpbmNlIChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCBUaGUgSGFsZi1CbG9vZCBQcmluY2UgKDcyMHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIEhhbGYtQmxvb2QgUHJpbmNlIDIwMDkgT3JpZ2luYWwgNzIwcCBIRC5tcDQ=", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD01ZGM4NWE4YzBiYTZmMWM4MGUyYTA0Njc1YjZhNWY4ZiZleHA9MTc3OTgxMzU5NSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgSGFsZi1CbG9vZCBQcmluY2UgKDIwMDkpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIEhhbGYtQmxvb2QgUHJpbmNlIChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCBUaGUgSGFsZi1CbG9vZCBQcmluY2UgKDEwODBwIEhEKS9IYXJyeSBQb3R0ZXIgYW5kIFRoZSBIYWxmLUJsb29kIFByaW5jZSAyMDA5IE9yaWdpbmFsIDEwODBwIEhELm1wNA==", className: "p1080" }
    ]
  },
  {
    title: "Harry Potter and the Goblet of Fire (2005)",
    image: "https://imgs.search.brave.com/jW14Z99bZG0OC5Y4t85XFO7-L_DlM8zIi4_Vt2PfSU4/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9zaG90/b253aGF0LmNvbS9p/bWFnZXMvMDMzMDM3/My5qcGc",
    movieName: "Harry Potter and the Goblet of Fire (2005)",
    director: "Mike Newell",
    starring: "Daniel Radcliffe, Rupert Grint, Emma Watson",
    genres: ["Adventure", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.8/10",
    lastUpdated: "06 January 2026",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD05OWUyOTZhOWE4MmY0NzlkMTY0Mjg0M2U4N2Y1bTExOWImZXhwPTE3Nzk4MTMyNzAmdmF0aD1UYW1pbCBEdWJiZWQgTW92aWVzL0hhcnJ5IFBvdHRlciBhbmQgdGhlIEdvYmxldCBvZiBGaXJlICoyMDA1KS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBHb2JsZXQgb2YgRmlyZSAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgdGhlIEdvYmxldCBvZiBGaXJlICgzNjBwIEhEKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBHb2JsZXQgb2YgRmlyZSAyMDA1IE9yaWdpbmFsIDM2MHAgSEQubXA0", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD05YWQyZGFkNzNjNWE1M2EwbTFlZDBiY2VjYjMxMWNjM2ImZXhwPTE3Nzk4MTMzMDQmdmF0aD1UYW1pbCBEdWJiZWQgTW92aWVzL0hhcnJ5IFBvdHRlciBhbmQgdGhlIEdvYmxldCBvZiBGaXJlICoyMDA1KS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBHb2JsZXQgb2YgRmlyZSAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgdGhlIEdvYmxldCBvZiBGaXJlICg3MjBwIEhEKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBHb2JsZXQgb2YgRmlyZSAyMDA1IE9yaWdpbmFsIDcyMHAgSEQubXA0", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD0xZjRlMzVmYjUwOTYxZGNjODY3OTEwMjk5YzBlZDgxMiZleHA9MTc3OTgxMzMyNyZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCB0aGUgR29ibGV0IG9mIEZpcmUgKDIwMDUpL0hhcnJ5IFBvdHRlciBhbmQgdGhlIEdvYmxldCBvZiBGaXJlIChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCB0aGUgR29ibGV0IG9mIEZpcmUgKDEwODBwIEhEKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBHb2JsZXQgb2YgRmlyZSAyMDA1IE9yaWdpbmFsIDEwODBwIEhELm1wNA==", className: "p1080" }
    ]
  },
  {
    title: "Harry Potter and The Prisoner of Azkaban (2004)",
    image: "https://imgs.search.brave.com/1ICKuwS1tQ-6QIxK39t5LNa8CSvnDhdHn2BwKFvQRj0/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9ydWtt/aW5pbTIuZmxpeGNh/cnQuY29tL2ltYWdl/LzgwMC84MDAvam1r/d3lhODAvcG9zdGVy/L3gvNS9wL2xhcmdl/LXdiLW9mZmljaWFs/LWxpY2Vuc2VkLWhh/cnJ5LXBvdHRlci1w/cmlzb25lci1vZi1h/emthYmFuLW9yaWdp/bmFsLWltYWY5Z2s2/enZrY3R1ZncuanBl/Zz9xPTkw",
    movieName: "Harry Potter and The Prisoner of Azkaban (2004)",
    director: "Alfonso Cuaron",
    starring: "Daniel Radcliffe, Rupert Grint, Emma Watson",
    genres: ["Adventure", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.0/10",
    lastUpdated: "06 January 2026",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD1mZDAxYjBhNGJhM2QwYzBiNjhkMGVhOTM5NDgwOTExOCZleHA9MTc3OTgxMjk5NSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgUHJpc29uZXIgb2YgQXprYWJhbiAoMjAwNCkvSGFycnkgUG90dGVyIGFuZCBUaGUgUHJpc29uZXIgb2YgQXprYWJhbiAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIFByaXNvbmVyIG9mIEF6a2FiYW4gKDM2MHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIFByaXNvbmVyIG9mIEF6a2FiYW4gMjAwNCBPcmlnaW5hbCAzNjBwIEhELm1wNA==", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD1iYTc0NzVlNzVhYTNhODZhMTRkODMxNjUxNTVmMzEzOSZleHA9MTc3OTgxMzAxNSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgUHJpc29uZXIgb2YgQXprYWJhbiAoMjAwNCkvSGFycnkgUG90dGVyIGFuZCBUaGUgUHJpc29uZXIgb2YgQXprYWJhbiAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIFByaXNvbmVyIG9mIEF6a2FiYW4gKDcyMHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIFByaXNvbmVyIG9mIEF6a2FiYW4gMjAwNCBPcmlnaW5hbCA3MjBwIEhELm1wNA==", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD1lNzY5OTQxZjA5ODk4ZGM5NjNhNmI3NzM1ZTQ3MWE2MiZleHA9MTc3OTgxMzA0NyZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCBUaGUgUHJpc29uZXIgb2YgQXprYWJhbiAoMjAwNCkvSGFycnkgUG90dGVyIGFuZCBUaGUgUHJpc29uZXIgb2YgQXprYWJhbiAoT3JpZ2luYWwpL0hhcnJ5IFBvdHRlciBhbmQgVGhlIFByaXNvbmVyIG9mIEF6a2FiYW4gKDEwODBwIEhEKS9IYXJyeSBQb3R0ZXIgYW5kIFRoZSBQcmlzb25lciBvZiBBemthYmFuIDIwMDQgT3JpZ2luYWwgMTA4MHAgSEQubXA0", className: "p1080" }
    ]
  },
  {
    title: "Harry Potter and the Chamber of Secrets (2002)",
    image: "https://imgs.search.brave.com/heCSzwa4UFCLXJobfEi1i_8niaiTEEjvlGfGQFrJEtc/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tZWRp/YS5oYXJyeXBvdHRl/cmZhbnpvbmUuY29t/L2NoYW1iZXItb2Yt/c2VjcmV0cy1oYXJyeS1wb3N0ZXIuanBn",
    movieName: "Harry Potter and the Chamber of Secrets (2002)",
    director: "Chris Columbus",
    starring: "Daniel Radcliffe, Rupert Grint, Emma Watson",
    genres: ["Adventure", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.7/10",
    lastUpdated: "27 December 2025",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD0yZGVjMmM2NGFlNWM3NWY1ZmJjNWVmNjNiMWQ1NmMwZiZleHA9MTc3OTgxMjY5MSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCB0aGUgQ2hhbWJlciBvZiBTZWNyZXRzICgyMDAyKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBDaGFtYmVyIG9mIFNlY3JldHMgKE9yaWdpbmFsKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBDaGFtYmVyIG9mIFNlY3JldHMgKDM2MHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgdGhlIENoYW1iZXIgb2YgU2VjcmV0cyAyMDAyIE9yaWdpbmFsIDM2MHAgSEQubXA0", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD1mZDY0YjQ1MTRmYTBlYTQ1OTViNWE3YzhiOGE1NTc4NCZleHA9MTc3OTgxMjcxNiZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCB0aGUgQ2hhbWJlciBvZiBTZWNyZXRzICgyMDAyKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBDaGFtYmVyIG9mIFNlY3JldHMgKE9yaWdpbmFsKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBDaGFtYmVyIG9mIFNlY3JldHMgKDcyMHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgdGhlIENoYW1iZXIgb2YgU2VjcmV0cyAyMDAyIE9yaWdpbmFsIDcyMHAgSEQubXA0", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD0yNzBjOTM0NWM5ZjEwMTQxZmZmMTBiNDE4MDkyNjBhYiZleHA9MTc3OTgxMjczNiZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCB0aGUgQ2hhbWJlciBvZiBTZWNyZXRzICgyMDAyKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBDaGFtYmVyIG9mIFNlY3JldHMgKE9yaWdpbmFsKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBDaGFtYmVyIG9mIFNlY3JldHMgKDEwODBwIEhEKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBDaGFtYmVyIG9mIFNlY3JldHMgMjAwMiBPcmlnaW5hbCAxMDgwcCBIRC5tcDQ=", className: "p1080" }
    ]
  },
  {
    title: "Harry Potter and the Sorcerers Stone (2001)",
    image: "https://imgs.search.brave.com/-5JRZ4bJvA7FdlaTj4lc1RAARCpRH_R9x8Ly8_Y5WHo/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/b3JpZ2luYWxmaWxt/YXJ0LmNvbS9jZG4v/c2hvcC9wcm9kdWN0/cy9oYXJyeV9wb3R0/ZXJfYW5kX3RoZV9w/aGlsb3NvcGhlcnNf/c3RvbmVfMjAwMV90/ZWFzZXJfb3JpZ2lu/YWxfZmlsbV9hcnRf/NjRhZGViM2QtNzk4/Yy00OWE1LWFkNzQt/ZjA0OTE2MDJiN2U5/LmpwZz92PTE2Mzg4/MzgwODkmd2lkdGg9/MTIwMA",
    movieName: "Harry Potter and the Sorcerers Stone (2001)",
    director: "Chris Columbus",
    starring: "Daniel Radcliffe, Rupert Grint, Emma Watson",
    genres: ["Adventure", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.9/10",
    lastUpdated: "27 December 2025",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD0xNDBjODUzM2RiOThjZmU1ZDdjNWE5NzFhZDc5MTRiZCZleHA9MTc3OTgxMjE2NyZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCB0aGUgU29yY2VyZXJzIFN0b25lICgyMDAxKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBTb3JjZXJlciBzIFN0b25lIChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCB0aGUgU29yY2VyZXIgcyBTdG9uZSAoMzYwcCBIRCkvSGFycnkgUG90dGVyIGFuZCB0aGUgU29yY2VyZXIgcyBTdG9uZSAyMDAxIE9yaWdpbmFsIDM2MHAgSEQubXA0", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD05OWQ2ZDJhNmVlNjIyYTIwMzJhN2I5MTZiMWExOTU4MCZleHA9MTc3OTgxMjE5MSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCB0aGUgU29yY2VyZXJzIFN0b25lICgyMDAxKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBTb3JjZXJlciBzIFN0b25lIChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCB0aGUgU29yY2VyZXIgcyBTdG9uZSAoNzIwcCBIRCkvSGFycnkgUG90dGVyIGFuZCB0aGUgU29yY2VyZXIgcyBTdG9uZSAyMDAxIE9yaWdpbmFsIDcyMHAgSEQubXA0", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjgmaGFzaD1kZGVjNTMwZmIxMzRiOWYyMjRmNjgyOTNmMmI2N2Q0MyZleHA9MTc3OTgxMjIzOSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSGFycnkgUG90dGVyIGFuZCB0aGUgU29yY2VyZXJzIFN0b25lICgyMDAxKS9IYXJyeSBQb3R0ZXIgYW5kIHRoZSBTb3JjZXJlciBzIFN0b25lIChPcmlnaW5hbCkvSGFycnkgUG90dGVyIGFuZCB0aGUgU29yY2VyZXIgcyBTdG9uZSAoMTA4MHAgSEQpL0hhcnJ5IFBvdHRlciBhbmQgdGhlIFNvcmNlcmVyIHMgU3RvbmUgMjAwMSBPcmlnaW5hbCAxMDgwcCBIRC5tcDQ=", className: "p1080" }
    ]
  }
];
