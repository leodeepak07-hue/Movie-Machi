import { Movie } from "../types";

export const moviesGroup2: Movie[] = [
  {
    title: "Dacoit A Love Story (2026)",
    image: "https://imgs.search.brave.com/w8O7z8wONRSDJIet4aI8XJimtv5pk0VJs6dtJ3lVCDs/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9kZS53/ZWIuaW1nMy5hY3N0/YS5uZXQvY18zMTBf/NDIwL2ltZy9mMC81/MS9mMDUxMDVhODRl/ZGM4Mjk1N2I1OTE0/MjhkYTE1ZTE1ZS53/ZWJw",
    movieName: "Dacoit A Love Story (2026)",
    director: "Shaneil Deo",
    starring: "Adivi Sesh, Mrunal Thakur, Anurag Kashyap",
    genres: ["Action", "Drama", "Romantic", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.0/10",
    lastUpdated: "08 May 2026",
    links: [
      { label: "Download 360p", url: "https://s01.cdnserver01.xyz/Moviesda.Mobi_-_Dacoit_A_Love_Story_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s11.cdnserver02.xyz/Moviesda.Mobi_-_Dacoit_A_Love_Story_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s02.cdnserver01.xyz/Moviesda.Mobi_-_Dacoit_A_Love_Story_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_Dacoit_A_Love_Story_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_Tam__Tel__Mal__Kan_-_DD5.1_-_640Kbps__AAC_-_10GB_-_ESub.mkv?token=bef1529004babbb0a48ac3e24fad374e&exp=1779988325", className: "K4" }
    ],
    watchUrl: "https://s22.cdnserver03.xyz/Moviesda.Mobi_-_Dacoit_A_Love_Story_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Vaazha II Biopic of a Billion Bros (2026)",
    image: "https://imgs.search.brave.com/WeZLXQC91DeeumSU6HKUF5Yg7G6RyEmgZJdCU71gjKA/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL1ZhYWxhLTJf/RU5HTElTSF9Qb3N0/ZXItNGU1ZWUxZTAt/M2ZhOS0xMWYxLTk0/NjQtZGZjZjMxMTk0/YjUxLmpwZw",
    movieName: "Vaazha II Biopic of a Billion Bros (2026)",
    director: "Savin Sa",
    starring: "Hashir H, Alan Bin Siraj, Ajin Joy",
    genres: ["Action", "Comedy", "Drama", "Family"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.4/10",
    lastUpdated: "08 May 2026",
    links: [
      { label: "Download 360p", url: "https://imgs.search.brave.com/Am7ehhQ0qzvh7YE8rpvMCplLAvl1fS_XsC58D2HVFj8/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9maWxt/dHJlbmR6LmNvbS91/cGxvYWRzL3Bvc3Rz/L2NvdmVycy9zeXN0/ZW0tMjAyNi1oaW5k/aS1kdWFsLWF1ZGlv/LXdlYmRsLTcyMHAt/LTQ4MHAtLTEwODBw/LndlYnA", className: "p480" },
      { label: "Download 720p", url: "https://s11.cdnserver02.xyz/Vaazha_II_Biopic_of_a_Billion_Bros_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s11.cdnserver02.xyz/Vaazha_II_Biopic_of_a_Billion_Bros_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_Vaazha_II_Biopic_of_a_Billion_Bros_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_Tam__Tel__Hin__Mal__Kan_-_DD5.1_-_192Kbps__AAC_-_5GB_-_ESub.mkv?token=83aa13c72140b3a65f86ad3f838c3d1c&exp=1779988413", className: "K4" }
    ],
    watchUrl: "https://s12.cdnserver02.xyz/Vaazha_II_Biopic_of_a_Billion_Bros_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Bharathanatyam 2 Mohiniyattam (2026)",
    image: "https://imgs.search.brave.com/8Moc9L8iRskE76ZB0ndfTQqMb1MpnJBdXQtd4oN4DlY/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9hc3Nl/dHMtaW4uYm1zY2Ru/LmNvbS9pZWRiL21v/dmllcy9pbWFnZXMv/bW9iaWxlL3RodW1i/bmFpbC94bGFyZ2Uv/YmhhcmF0aGFuYXR5/YW0tMi1tb2hpbml5/YXR0YW0tZXQwMDQ5/Mjg3NC0xNzc0NTEx/NDQ1LmpwZw",
    movieName: "Bharathanatyam 2 Mohiniyattam (2026)",
    director: "Krishnadas Murali",
    starring: "Saiju Kurup, Suraj Venjaramoodu, Baby Jean",
    genres: ["Comedy", "Family", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.2/10",
    lastUpdated: "08 May 2026",
    links: [
      { label: "Download 360p", url: "https://s05.cdnserver01.xyz/Bharathanatyam_2_Mohiniyattam_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s24.cdnserver03.xyz/Bharathanatyam_2_Mohiniyattam_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s21.cdnserver03.xyz/Bharathanatyam_2_Mohiniyattam_2026_Original_1080p_HD_(3.4_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_Bharathanatyam_2_Mohiniyattam_2026_TRUE_WEB-DL_-_4K_SDR_-_2160p_HQ_-_HEVC_-_Tamil__Telugu__Hindi__Kannada__Malayalam.mkv?token=abaecc85b4c6babcd0e3fa240ba940x9&exp=1779988502", className: "K4" }
    ],
    watchUrl: "https://s23.cdnserver03.xyz/Bharathanatyam_2_Mohiniyattam_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Love 911 (2024)",
    image: "https://imgs.search.brave.com/9h-x6UlPiNZ9voVa0OSpJVTKrlMQtFgRxjrDLTLV3jg/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4ubW92aWVmb25lLmNvbS9pbWFnZS1hc3NlL3MxNDY3MjQvYUIxelpjNUJOSFNhUWxFaE9Tbmk0dHM4RHJMLmpwZz9kPTM2MHg1NDAmcT04MA",
    movieName: "Love 911 (2024)",
    director: "Gi-hoon Jeong",
    starring: "Go Soo, Han Hyo-joo",
    genres: ["Comedy", "Drama", "Romance"],
    quality: "BDRip",
    language: "Tamil",
    rating: "6.9/10",
    lastUpdated: "30 October 2024",
    links: [
      { label: "Download 560p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjImaGFzaD04MTk5N2UxYWYyNWMyN2EyZWJlMzViMmM2YzIxZTVkYyZleHA9MTc3OTg0NzA3NCZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvTG92ZSA5MTEgKDIwMjQpL0xvdmUgOTExIChPcmlnaW5hbCkvTG92ZSA5MTEgKDM2MHAgSEQpL0xvdmUgOTExIDIwMjQgMzYwcCBIRC5tcDQ=", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjImaGFzaD0zNTA3MTI1ZjNkOTk4MTM4NjhhYjNiNmFjOWJiMzNkZCZleHA9MTc3OTg0NzA5NiZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvTG92ZSA5MTEgKDIwMjQpL0xvdmUgOTExIChPcmlnaW5hbCkvTG92ZSA5MTEgKDcyMHAgSEQpL0xvdmUgOTExIDIwMjQgNzIwcCBIRC5tcDQ=", className: "p1080" }
    ],
    watchUrl: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjImaGFzaD1jYjZiM2ZkMzdhYzgwZGQ4M2U4NGI0MjQxY2Y4OTk5MyZleHA9MTc3OTg5ODc0NSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvTG92ZSA5MTEgKDIwMjQpL0xvdmUgOTExIChPcmlnaW5hbCkvTG92ZSA5MTEgKDcyMHAgSEQpL0xvdmUgOTExIDIwMjQgNzIwcCBIRC5tcDQ=&stream=1"
  },
  {
    title: "Love Insurance Kompany (2026)",
    image: "https://imgs.search.brave.com/J8EhMmS7TVRayJjwIrq7wdjY-2YI_c0IjcxeERp2I4Q/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9wcmV2/aWV3LnJlZGQuaXQv/bG92ZS1pbnN1cmFu/Y2Uta29tcGFueS0y/MDI2LW5vdy1zdHJl/YW1pbmctb24tYW1h/em9uLXByaW1lLXYw/LThzbzdmYW4waWZ6/ZzEuanBlZz93aWR0/aD02NDAmY3JvcD1z/bWFydCZhdXRvPXdl/YnAmcz03YTYxMmQ0/OTI5NTUxN2ZkOWI2/N2Y0M2YzNjM1NDNj/MWI1MDI5MGVj",
    movieName: "Love Insurance Kompany (2026)",
    director: "Vignesh Shivan",
    starring: "Pradeep Ranganathan, Krithi Shetty",
    genres: ["Comedy", "Romantic", "Sci-Fi"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.0/10",
    lastUpdated: "06 May 2026",
    links: [
      { label: "Download 360p", url: "https://s01.cdnserver01.xyz/Moviesda.Mobi_-_Love_Insurance_Kompany_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Love_Insurance_Kompany_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s14.cdnserver02.xyz/Moviesda.Mobi_-_Love_Insurance_Kompany_2026_Original_1080p_HD_(3.6_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-LIK_Love_Insurance_Kompany_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_UNTOUCHED_-_Tamil__Telugu__Hindi__Kannada__Malayalam.mkv?token=afc672e9ae939730662d332224ac96ec&exp=1779988614", className: "K4" }
    ],
    watchUrl: "https://s14.cdnserver02.xyz/Moviesda.Mobi_-_Love_Insurance_Kompany_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "The Girlfriend (2025)",
    image: "https://pbs.twimg.com/media/G6WsYh2aUAA-AV2.jpg",
    movieName: "The Girlfriend (2025)",
    director: "Rahul Ravindran",
    starring: "Dheekshith Shetty, Rashmika Mandanna, Rao Ramesh",
    genres: ["Drama", "Romantic"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.6/10",
    lastUpdated: "05 December 2025",
    links: [
      { label: "Download 360p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTAxZTFjOTRhMzU1ZGY3Yzc4YjM1ZDAwOGEwMzNiOGEzJmV4cD0xNzc5OTg2NDY4JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvVGhlIEdpcmxmcmllbmQgKDIwMjUpL1RoZSBHaXJsZnJpZW5kIChPcmlnaW5hbCkvVGhlIEdpcmxmcmllbmQgKDM2MHAgSEQpL01vdmllc2RhLk1vYmkgLSBUaGUgR2lybGZyaWVuZCAyMDI1IE9yaWdpbmFsIDM2MHAgSEQubXA0", className: "p480" },
      { label: "Download 720p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTEwYTM4M2IyNjM2ZmRmMGY5YTU2OWM1ZDI1YTg0NzU5JmV4cD0xNzc5OTg2NTAxJnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvVGhlIEdpcmxmcmllbmQgKDIwMjUpL1RoZSBHaXJsZnJpZW5kIChPcmlnaW5hbCkvVGhlIEdpcmxmcmllbmQgKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBUaGUgR2lybGZyaWVuZCAyMDI1IE9yaWdpbmFsIDcyMHAgSEQubXA0", className: "p720" },
      { label: "Download 1080p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTEwMzkwNjczOGUyYWRkYzc1OGIxYzY3OWU0MzBkMTRmJmV4cD0xNzc5OTg2NzUxJnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvVGhlIEdpcmxmcmllbmQgKDIwMjUpL1RoZSBHaXJsZnJpZW5kIChPcmlnaW5hbCkvVGhlIEdpcmxmcmllbmQgKDEwODBwIEhEKS9Nb3ZpZXNkYS5Nb2JpIC0gVGhlIEdpcmxmcmllbmQgMjAyNSBPcmlnaW5hbCAxMDgwcCBIRCubXA0", className: "p1080" }
    ],
    watchUrl: "https://mv1.uptomkv.ch/files/Tamil%202025%20Movies/The%20Girlfriend%20(2025)/The%20Girlfriend%20(Original)/The%20Girlfriend%20(720p%20HD)/Moviesda.Mobi%20-%20The%20Girlfriend%202025%20Original%20720p%20HD.mp4?h=e1ebf6836442228d1ba609fc90bcbcd7c5573967984099a716874bb1aa8e05c7&e=1780850503"
  },
  {
    title: "Iron Man 3 (2013)",
    image: "https://imgs.search.brave.com/TtEaa5jhrd1pOAvYreC9n6vX_5r48Y0ZDD-jyi-EIUU/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL0kv/NjE4ajVudkRpV0wu/anBn",
    movieName: "Iron Man 3 (2013)",
    director: "Shane Black",
    starring: "Robert Downey Jr., Gwyneth Paltrow",
    genres: ["Action", "Adventure", "Sci-Fi"],
    quality: "BDRip",
    language: "Tamil",
    rating: "7.2/10",
    lastUpdated: "28 January 2021",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjYmaGFzaD1iYWNkNzYwZjRhM2NhMDcyMTcwMzYyNGJmOWEyMDFlMyZleHA9MTc3OTgxNTcwMSZwYXRoPVRhbWlsIER1YmJlZCBDb2xsZWN0aW9ucy8gSXJvbiBNYW4gVHJpbG9neSBDb2xsZWN0aW9ucy9Jcm9uIE1hbiAzICgyMDEzKS9Jcm9uIE1hbiAzICg0ODB4MzIwKS9Jcm9uIE1hbiAzLm1wNA==", className: "p480" },
      { label: "Download 560p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjYmaGFzaD0wODg2M2E4Y2FhMGRiYWFjZGNmZmI5ZDcxMTg5ZWViOSZleHA9MTc3OTgxNTczMCZwYXRoPVRhbWlsIER1YmJlZCBDb2xsZWN0aW9ucy8gSXJvbiBNYW4gVHJpbG9neSBDb2xsZWN0aW9ucy9Jcm9uIE1hbiAzICgyMDEzKS9Jcm9uIE1hbiAzICg2NDB4MzYwKS9Jcm9uIE1hbiAzIEhELm1wNA==", className: "p720" }
    ],
    watchUrl: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjYmaGFzaD0wYTRiNzNlY2E5YjJlOTdhYTdjYTdmMjNiYmQ4NGExZSZleHA9MTc3OTg5OTk2OCZwYXRoPVRhbWlsIER1YmJlZCBDb2xsZWN0aW9ucy8gSXJvbiBNYW4gVHJpbG9neSBDb2xsZWN0aW9ucy9Jcm9uIE1hbiAzICgyMDEzKS9Jcm9uIE1hbiAzICg2NDB4MzYwKS9Jcm9uIE1hbiAzIEhELm1wNA==&stream=1"
  },
  {
    title: "Iron Man 2 (2010)",
    image: "https://imgs.search.brave.com/folb-nmfiLYd5_Z_yezM1Ni7TlcsPjukgTDyCbdL-VM/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93YWxs/cGFwZXJjYXQuY29t/L3cvZnVsbC81Lzcv/Yi8yMTM5MzcwLTE0/MDB4MjEwMC1waG9u/ZS1oZC1pcm9uLW1h/bi0yLWJhY2tncm91/bmQtcGhvdG8uanBn",
    movieName: "Iron Man 2 (2010)",
    director: "Jon Favreau",
    starring: "Robert Downey Jr., Gwyneth Paltrow",
    genres: ["Action", "Adventure", "Sci-Fi"],
    quality: "BDRip",
    language: "Tamil",
    rating: "7.0/10",
    lastUpdated: "28 January 2021",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjYmaGFzaD1hNTdjOGY0NTgyMDQyNTMzNDU4OWY3YzU1MWNkYWZjNCZleHA9MTc3OTgxNTQ2NSZwYXRoPVRhbWlsIER1YmJlZCBDb2xsZWN0aW9ucy8gSXJvbiBNYW4gVHJpbG9neSBDb2xsZWN0aW9ucy9Jcm9uIE1hbiAyICgyMDEwKS9Jcm9uIE1hbiAyICg0ODB4MzIwKS9Jcm9uIE1hbiAyLm1wNA==", className: "p480" },
      { label: "Download 560p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjYmaGFzaD0yYTEzNmFmYTU1MjFkMjdjNzczZjk2OGZhZGI0YjRiMiZleHA9MTc3OTgxNTQ4NSZwYXRoPVRhbWlsIER1YmJlZCBDb2xsZWN0aW9ucy8gSXJvbiBNYW4gVHJpbG9neSBDb2xsZWN0aW9ucy9Jcm9uIE1hbiAyICgyMDEwKS9Jcm9uIE1hbiAyICg2NDB4MzYwKS9Jcm9uIE1hbiAyIEhELm1wNA==", className: "p720" }
    ],
    watchUrl: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjYmaGFzaD0yNTE4MjU0N2JhOWQxZDcxNWMwMzE3NDUzMjQ3MGJkYiZleHA9MTc3OTg5OTAyMiZwYXRoPVRhbWlsIER1YmJlZCBDb2xsZWN0aW9ucy8gSXJvbiBNYW4gVHJpbG9neSBDb2xsZWN0aW9ucy9Jcm9uIE1hbiAyICgyMDEwKS9Jcm9uIE1hbiAyICg2NDB4MzYwKS9Jcm9uIE1hbiAyIEhELm1wNA==&stream=1"
  },
  {
    title: "Iron Man 1 (2008)",
    image: "https://imgs.search.brave.com/KJ1ruoCHwn76heFLU2ObEJMxYLCyI0o8SsPhzoUd7jQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93YWxs/cGFwZXJhY2Nlc3Mu/Y29tL2Z1bGwvMjA2/OTQ5MS5qcGc",
    movieName: "Iron Man 1 (2008)",
    director: "Jon Favreau",
    starring: "Robert Downey Jr., Terrence Howard",
    genres: ["Action", "Adventure", "Sci-Fi"],
    quality: "BDRip",
    language: "Tamil",
    rating: "7.9/10",
    lastUpdated: "28 January 2021",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjYmaGFzaD1kOTE4YjRjNTFjZmI3OGYyOTcyOTlhOGY5ZjQxZTlmZiZleHA9MTc3OTgxNTE5MyZwYXRoPVRhbWlsIER1YmJlZCBDb2xsZWN0aW9ucy8gSXJvbiBNYW4gVHJpbG9neSBDb2xsZWN0aW9ucy9Jcm9uIE1hbiAxICgyMDA4KS9Jcm9uIE1hbiAxICg0ODB4MzIwKS9Jcm9uIE1hbiAxLm1wNA==", className: "p480" },
      { label: "Download 560p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjYmaGFzaD1lYTQwZWZiZGVlYTBlMjdiYjgyZDAyYmIwYWJiMjAzZSZleHA9MTc3OTgxNTIxOCZwYXRoPVRhbWlsIER1YmJlZCBDb2xsZWN0aW9ucy8gSXJvbiBNYW4gVHJpbG9neSBDb2xsZWN0aW9ucy9Jcm9uIE1hbiAxICgyMDA4KS9Jcm9uIE1hbiAxICg2NDB4MzYwKS9Jcm9uIE1hbiAxIEhELm1wNA==", className: "p720" }
    ],
    watchUrl: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjYmaGFzaD1lZjYxNGZmYzlhZDUyODQwZmU2Nzc5MmJmN2YxYTFlYiZleHA9MTc3OTg5OTA3NCZwYXRoPVRhbWlsIER1YmJlZCBDb2xsZWN0aW9ucy8gSXJvbiBNYW4gVHJpbG9neSBDb2xsZWN0aW9ucy9Jcm9uIE1hbiAxICgyMDA4KS9Jcm9uIE1hbiAxICg2NDB4MzYwKS9Jcm9uIE1hbiAxIEhELm1wNA==&stream=1"
  },
  {
    title: "IT Chapter Two (2019)",
    image: "https://imgs.search.brave.com/617O5H6n2MVUlA4htSymt3gW--z5YvZ8ohOH-T6jS_E/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL0kv/ODExTENVK1IzRUwu/anBn",
    movieName: "IT Chapter Two (2019)",
    director: "Andy Muschietti",
    starring: "Bill Skarsgard, James McAvoy, Jessica Chastain",
    genres: ["Horror", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "6.8/10",
    lastUpdated: "29 October 2025",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjcmaGFzaD1hMjM5YTUxMWM4MjRlODRkZDEwOTljOWQ2ZjIyYTJkMiZleHA9MTc3OTgxNDgzNyZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSVQgQ2hhcHRlciBUd28gKDIwMTkpL0lUIENoYXB0ZXIgVHdvIChPcmlnaW5hbCkvSVQgQ2hhcHRlciBUd28gKDM2MHAgSEQpL0lUIENoYXB0ZXIgVHdvIDIwMTkgT3JpZ2luYWwgMzYwcCBIRC5tcDQ=", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjcmaGFzaD0zODc3NDU1YzMzOWJhMjg4ZmZhYmE4ZmNlMzhkMWYxMiZleHA9MTc3OTgxNDU5OSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSVQgQ2hhcHRlciBUd28gKDIwMTkpL0lUIENoYXB0ZXIgVHdvIChPcmlnaW5hbCkvSVQgQ2hhcHRlciBUd28gKDcyMHAgSEQpL0lUIENoYXB0ZXIgVHdvIDIwMTkgT3JpZ2luYWwgNzIwcCBIRC5tcDQ=", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjcmaGFzaD1jNTc4ZmQxYTZmMzFiYWQ4NjhhZGRkOTQ2YTYwNzBlNCZleHA9MTc3OTgxNDg3OSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSVQgQ2hhcHRlciBUd28gKDIwMTkpL0lUIENoYXB0ZXIgVHdvIChPcmlnaW5hbCkvSVQgQ2hhcHRlciBUd28gKDEwODBwIEhEKS9JVCBDaGFwdGVyIFR3byAyMDE5IE9yaWdpbmFsIDEwODBwIEhELm1wNA==", className: "p1080" }
    ],
    watchUrl: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjcmaGFzaD02MjM4MmU5MTUzNjZmZGEzMGEwODU4YTg3ZTgxYzZlMiZleHA9MTc3OTg5OTE0OCZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSVQgQ2hhcHRlciBUd28gKDIwMTkpL0lUIENoYXB0ZXIgVHdvIChPcmlnaW5hbCkvSVQgQ2hhcHRlciBUd28gKDEwODBwIEhEKS9JVCBDaGFwdGVyIFR3byAyMDE5IE9yaWdpbmFsIDEwODBwIEhELm1wNA==&stream=1"
  },
  {
    title: "IT Chapter One (2017)",
    image: "https://imgs.search.brave.com/bsyFCmiUfIbFj9KDqfkkSC74JFaA4wFCCEv3xwbae54/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL0kv/ODF1T0xJSXJzSkwu/anBn",
    movieName: "IT Chapter One (2017)",
    director: "Andy Muschietti",
    starring: "Bill Skarsgard, Jaeden Martell, Sophia Lillis",
    genres: ["Horror", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.2/10",
    lastUpdated: "29 October 2025",
    links: [
      { label: "Download 360p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjcmaGFzaD05NmMxYWEzZDE0MjlkODRjYTdkMWNiZTkwOTViNWM2MyZleHA9MTc3OTgxNDU3MSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSVQgKDIwMTcpL0lUIChPcmlnaW5hbCkvSVQgKDM2MHAgSEQpL0lUIDIwMTcgT3JpZ2luYWwgMzYwcCBIRC5tcDQ=", className: "p480" },
      { label: "Download 720p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjcmaGFzaD1kYzMwMzE5MTMwNzMzNmQ5NTY5MmZhYWI2MzBhNzIwMSZleHA9MTc3OTgxNDU5MSZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSVQgKDIwMTcpL0lUIChPcmlnaW5hbCkvSVQgKDcyMHAgSEQpL0lUIDIwMTcgT3JpZ2luYWwgNzIwcCBIRC5tcDQ=", className: "p720" },
      { label: "Download 1080p", url: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjcmaGFzaD05M2Q5MGZhZWNmMzcwN2MxOGE1OTM0YmRjOWMwZDUyNiZleHA9MTc3OTgxNDYxMiZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSVQgKDIwMTcpL0lUIChPcmlnaW5hbCkvSVQgKDEwODBwIEhEKS9JVCAyMDE3IE9yaWdpbmFsIDEwODBwIEhELm1wNA==", className: "p1080" }
    ],
    watchUrl: "https://dub.uptodub.ch/download.php?dl=c2VydmVyPWR1YjcmaGFzaD00MGIxZmUzODA4M2M1MjlkYmQzNzMyZDUwYWVkNTgxOSZleHA9MTc3OTg5OTIwNCZwYXRoPVRhbWlsIER1YmJlZCBNb3ZpZXMvSVQgKDIwMTcpL0lUIChPcmlnaW5hbCkvSVQgKDEwODBwIEhEKS9JVCAyMDE3IE9yaWdpbmFsIDEwODBwIEhELm1wNA==&stream=1"
  },
  {
    title: "Justice for Jeni (2026)",
    image: "https://imgs.search.brave.com/jlTrsb4GSrcT1ETRWd5Gibi0qZfDOTwA7GtYE9RzgCA/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pMC53/cC5jb20vd3d3Lm5haWphdmF1bHQuY29tL3dwLWNvbnRl/bnQvdXBsb2Fkcy8y/MDI2LzA0L2p1c3Rp/Y2UtZm9yLWplbmkud2Vi/cD93PTY3OCZzc2w9/MQ",
    movieName: "Justice for Jeni (2026)",
    director: "Santhosh Ryan",
    starring: "Ashika Asokan, Sandhra Anil, Sinan",
    genres: ["Drama", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.2/10",
    lastUpdated: "05 May 2026",
    links: [
      { label: "Download 360p", url: "https://s01.cdnserver01.xyz/Moviesda.Mobi_-_Justice_for_Jeni_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s03.cdnserver01.xyz/Moviesda.Mobi_-_Justice_for_Jeni_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s01.cdnserver01.xyz/Moviesda.Mobi_-_Justice_for_Jeni_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_Justice_for_Jeni_2026_Tamil_TRUE_WEB-DL_-_1080p_-_AVC_-_DD5.1_-_640Kbps__AAC_-_6GB_-_ESub.mkv?token=1d90c131cb30020116d6c19cc5cbe95a&exp=1779988811", className: "K4" }
    ],
    watchUrl: "https://s22.cdnserver03.xyz/Moviesda.Mobi_-_Justice_for_Jeni_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Oh Butterfly (2026)",
    image: "https://imgs.search.brave.com/50xRQFwML8OTDFNdDVE31XAi7htYZsXQEG5Ca1faK-o/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9hc3Nl/dHMtaW4uYm1zY2Ru/LmNvbS9pZWRiL21v/dmllcy9pbWFnZXMv/bW9iaWxlL3RodW1i/bmFpbC94bGFyZ2Uv/b2gtYnV0dGVyZmx5/LWV0MDA0OTAwNjUt/MTc3MjYxMzYzMi5q/cGc",
    movieName: "Oh Butterfly (2026)",
    director: "Vijay Ranganathan",
    starring: "Nivedhithaa Sathish, Ciby Bhuvana Chandran, Attul R.",
    genres: ["Crime", "Romantic", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.8/10",
    lastUpdated: "01 May 2026",
    links: [
      { label: "Download 360p", url: "https://s24.cdnserver03.xyz/Moviesda.Mobi_-_Oh_Butterfly_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s22.cdnserver03.xyz/Moviesda.Mobi_-_Oh_Butterfly_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_Oh_Butterfly_2026_Original_1080p_HD_(3.6_GB).mp4", className: "p1080" }
    ],
    watchUrl: "https://s13.cdnserver02.xyz/Moviesda.Mobi_-_Oh_Butterfly_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Manithan Deivamagalam (2026)",
    image: "https://imgs.search.brave.com/957zWzr-J0duL5LDSAojKW_r6024WZuCN0NfJNarRKQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMuZGluYW1hbGFy/bW9iaWxlL2Npbmkv/Q2luZUdhbGxlcnkv/Vk1fMjAyNjA0MTAx/MzE2MDYwMDAw/MDAuanBn",
    movieName: "Manithan Deivamagalam (2026)",
    director: "Dennis Manjunath",
    starring: "K. Selvaraghavan, Kushee Ravi, R. S. Sathish",
    genres: ["Action", "Crime", "Drama", "Family"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.7/10",
    lastUpdated: "01 May 2026",
    links: [
      { label: "Download 360p", url: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_Manithan_Deivamagalam_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s31.cdnserver04.xyz/Moviesda.Mobi_-_Manithan_Deivamagalam_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_Manithan_Deivamagalam_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_Manithan_Deivamagalam_2026_Tamil_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_DD5.1_-_192Kbps__AAC_-_5.8GB_-_ESub.mkv?token=38e4399573e7b42280eaffa82b974667&exp=1779988892", className: "K4" }
    ],
    watchUrl: "https://s05.cdnserver01.xyz/Moviesda.Mobi_-_Manithan_Deivamagalam_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "The Kerala Story 2 Goes Beyond (2026)",
    image: "https://imgs.search.brave.com/JYrlQP1lFsxW4_Im52i-OFuNrNggF7i0QEoFxTvLKlU/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL00v/TVY1QlpHUmxOREl4/TlRndE5tTXdaaTAw/TlRjd0xXSTFOVEF0/WVRKbU5qaGxOalEy/TXprMVhrRXlYa0Zx/Y0djQC5qcGc",
    movieName: "The Kerala Story 2 Goes Beyond (2026)",
    director: "Kamakhya Narayan Singh",
    starring: "Ulka Gupta, Aditi Bhatia, Aishwarya Ojha",
    genres: ["Drama", "Social"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.2/10",
    lastUpdated: "01 May 2026",
    links: [
      { label: "Download 360p", url: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_The_Kerala_Story_2_Goes_Beyond_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s05.cdnserver01.xyz/Moviesda.Mobi_-_The_Kerala_Story_2_Goes_Beyond_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s05.cdnserver01.xyz/Moviesda.Mobi_-_The_Kerala_Story_2_Goes_Beyond_2026_Original_1080p_HD_(3.4_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamiMV.center_-_The_Kerala_Story_2_Goes_Beyond_2026_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_Tam__Tel__Hin__Mal__Kan_-_DD5.1_-_192Kbps_-_5.2GB_-_ESub.mkv?token=5e67c562657daff7065ef35fd235067c&exp=1779988967", className: "K4" }
    ],
    watchUrl: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_The_Kerala_Story_2_Goes_Beyond_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Kayilan (2025)",
    image: "https://imgs.search.brave.com/_Z1jG1zt3OZWQFWooVy489d4h9cgiA4zMQTqAxS_-Jk/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/bnx0c2hvd3Mu/Y29tL2ltYWdlcy90/YW1pbC1tb3ZpZXMv/S2F5aWxhbi1Nb3Zp/ZS1Qb3N0ZXIud2VicA",
    movieName: "Kayilan (2025)",
    director: "Arul Ajit",
    starring: "Sshivada Nair, Ramya Pandian, Manobala",
    genres: ["Drama", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.9/10",
    lastUpdated: "01 May 2026",
    links: [
      { label: "Download 360p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Kayilan_2025_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_Kayilan_2025_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s31.cdnserver04.xyz/Moviesda.Mobi_-_Kayilan_2025_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_Kayilan_2025_Tamil_TRUE_WEB-DL_-_4K_SDR_-_2160p_HQ_-_DD5.1_-_192Kbps__AAC_2.0_-_5.2GB_-_ESub.mkv?token=848898562ade3de81381427120927b1a&exp=1779989033", className: "K4" }
    ],
    watchUrl: "https://s35.cdnserver04.xyz/Moviesda.Mobi_-_Kayilan_2025_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Aadu 3 (2026)",
    image: "https://imgs.search.brave.com/HpocrwLDzN_XaQRPBeccJrxS-5WKEFLGDoKJn2ZNgfU/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZS50bWRiLm9yZy90/L3AvdzYwMF9hbmRf/aDkwMF9iZXN0djIv/NHl6WUY2TUdKOW9a/R29idHRpaVV6MFJZ/cFJYLmpwZw",
    movieName: "Aadu 3 (2026)",
    director: "Midhun Manuel Thomas",
    starring: "Jayasurya, Vinayakan T. K., Saiju Kurup",
    genres: ["Comedy", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.7/10",
    lastUpdated: "01 May 2026",
    links: [
      { label: "Download 360p", url: "https://s35.cdnserver04.xyz/Aadu_3_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s14.cdnserver02.xyz/Aadu_3_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s34.cdnserver04.xyz/Aadu_3_2026_Original_1080p_HD_(3.4_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_Aadu_3_2026_TRUE_WEB-DL_-_4K_SDR_-_2160p_HQ_-_HEVC_-_UNTOUCHED_-_Tamil__Telugu__Hindi__Malayalam__Kannada.mkv?token=7fa5dfd9d8f90fffff5bca5876dbce6a&exp=1779989120", className: "K4" }
    ],
    watchUrl: "https://s24.cdnserver03.xyz/Aadu_3_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Raakaasa (2026)",
    image: "https://imgs.search.brave.com/6-gsZwR0BsP6AIP8xZuZgbQZHNAkSP0pLQCOWFGgpE0/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly91cGxv/YWQud2lraW1lZGlh/Lm9yZy93aWtpcGVk/aWEvY29tbW9ucy9i/L2I1L1JhYWthYXNh/XygyMDI2KV9maWxt/LmpwZw",
    movieName: "Raakaasa (2026)",
    director: "Manasa Sharma",
    starring: "Sangeeth Shobhan, Nayan Sarika, Getup Srinu",
    genres: ["Comedy", "Fantasy", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.5/10",
    lastUpdated: "01 May 2026",
    links: [
      { label: "Download 360p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Raakaasa_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s22.cdnserver03.xyz/Moviesda.Mobi_-_Raakaasa_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_Raakaasa_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_Raakaasa_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_Tam__Tel__Mal__Kan_-_DD5.1_-_640Kbps__AAC_-_8.8GB_-_ESub.mkv?token=8c5ab614d669459a11ccd96a1bf310d6&exp=1779989181", className: "K4" }
    ],
    watchUrl: "https://s13.cdnserver02.xyz/Moviesda.Mobi_-_Raakaasa_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Biker (2026)",
    image: "https://imgs.search.brave.com/2EYuHnGtgd7LBM-K1bFSidnJMF9F9h2EXp-854y4i0c/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzdHJpY3QuaW4v/bW92aWVzLWFzc2V0/cy9pbWFnZXMvY2lu/ZW1hL0JpbGVyLWRi/OGZjODUwLTMxZGUt/MTFmMS1hMDA1LTYz/ODgyYTkxYzYzOC5q/cGc_aW09UmVzaXpl/LHdpZHRoPTMyMA",
    movieName: "Biker (2026)",
    director: "Abhilash Kankara",
    starring: "Sharwanand, Rajasekhar, Malavika Nair",
    genres: ["Action", "Drama", "Romantic", "Sports"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.3/10",
    lastUpdated: "01 May 2026",
    links: [
      { label: "Download 360p", url: "https://s24.cdnserver03.xyz/Moviesda.Mobi_-_Biker_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s14.cdnserver02.xyz/Moviesda.Mobi_-_Biker_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Biker_2026_Original_1080p_HD_(3.4_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_Biker_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_Tamil__Telugu__Hindi__Malayalam__Kannada_-_DD5.1_-_640Kbps__AAC_2.0.mkv?token=c13e8adaa64a24f961b5c229057c8a43&exp=1779989289", className: "K4" }
    ],
    watchUrl: "https://s32.cdnserver04.xyz/Moviesda.Mobi_-_Biker_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "TN 2026 (2026)",
    image: "https://imgs.search.brave.com/BtuHNg4FMPGdaPaNztQh_SzpvvNlYOAah_ouNQE-56Y/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMuZmlsbWliZWF0/LmNvbS9pbWcvMjgw/eDM4My9wb3Bjb3Ju/L21vdmllX3Bvc3Rl/cnMvdG4yMDI2dGhh/bmdhbmF0Y2hhdGhp/cmFtLTIwMjYwMzMw/MTE0MDI3LTI0Mjk4/LmpwZw",
    movieName: "TN 2026 (2026)",
    director: "Umapathi Ramaiah",
    starring: "Natty Subramaniam, Thambi Ramaiah, Shrita Rao",
    genres: ["Action", "Drama"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.8/10",
    lastUpdated: "30 April 2026",
    links: [
      { label: "Download 360p", url: "https://s03.cdnserver01.xyz/Moviesda.Mobi_-_TN_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s11.cdnserver02.xyz/Moviesda.Mobi_-_TN_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s14.cdnserver02.xyz/Moviesda.Mobi_-_TN_2026_Original_1080p_HD_(3.5_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.center_-_TN_2026_2026_Tamil_TRUE_WEB-DL_-_1080p_-_AVC_-_DD5.1_-_640Kbps__AAC_2.0_-_4.5GB_-_ESub.mkv?token=cf61d0212d82d37ce3fe361f20702ede&exp=1779989358", className: "K4" }
    ],
    watchUrl: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_TN_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Viraaji (2026)",
    image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/viraaji-et00405762-1721800912.jpg",
    movieName: "Viraaji (2026)",
    director: "Adhyanth Harsha",
    starring: "Varun Sandesh, Aparna Thampi, Kushalini Puliapa",
    genres: ["Mystery", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.0/10",
    lastUpdated: "26 April 2026",
    links: [
      { label: "Download 360p", url: "https://s22.cdnserver03.xyz/Moviesda.Mobi_-_Viraaji_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_Viraaji_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s11.cdnserver02.xyz/Moviesda.Mobi_-_Viraaji_2026_Original_1080p_HD_(1.5_GB).mp4", className: "p1080" }
    ],
    watchUrl: "https://s11.cdnserver02.xyz/Moviesda.Mobi_-_Viraaji_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Hot Spot 2 Much (2026)",
    image: "https://imgs.search.brave.com/vhZE5kT5XoDUUYNuO0IISILv7oaFzkEgQtTnk5gnk_8/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMuZGluYW1hbGFy/bW9iaWxlL2Npbmkv/Q2luZUdhbGxlcnkv/Vk1fMjAyNjAyMjEx/NTU3NDQwMDAw/MDAuanBn", /* note fallback link */
    movieName: "Hot Spot 2 Much (2026)",
    director: "Vignesh Karthick",
    starring: "Priya Bhavani Shankar, Brigida Saga, Ashwin Kumar Lakshmikanthan",
    genres: ["Comedy", "Drama", "Romantic"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.5/10",
    lastUpdated: "20 February 2026",
    links: [
      { label: "Download 360p", url: "https://dl1.biggshare.xyz/Moviesda.Mobi_-_Hot_Spot_2_Much_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s07.hotshare.link/Moviesda.Mobi_-_Hot_Spot_2_Much_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s01.hotshare.link/Moviesda.Mobi_-_Hot_Spot_2_Much_2026_Original_1080p_HD__3.4_GB_.mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.earth_-_Hot_Spot_2_Much_2026_Tamil_TRUE_WEB-DL_-_4K_SDR_-_2160p_HQ_-_HEVC_-_DD5.1_-_640Kbps__AAC_-_7.7GB_-_ESub.mkv?token=f5e4fff1539830a4f930f71e58d5a7ac&exp=1779989472", className: "K4" }
    ],
    watchUrl: "https://dl5.biggshare.xyz/Moviesda.Mobi_-_Hot_Spot_2_Much_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Lucky the Superstar (2026)",
    image: "https://imgs.search.brave.com/1JEToD1zh-luVKtQv3LgzloXXo0FcGQrtehNkulkbEE/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWcu/c3R1ZGlvZmxpY2tz/LmNvbS93cC1jb250/ZW50L3VwbG9hZHMv/MjAyNi8wMy8wOTE5/MzEzNy9MdWNreS10/aGUtU3VwZXJzdGFy/LmpwZw",
    movieName: "Lucky the Superstar (2026)",
    director: "Udhayabanu Maheshwaran",
    starring: "G.V. Prakash Kumar, Anaswara Rajan, R. Sarathkumar",
    genres: ["Drama", "Comedy", "Kids"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.1/10",
    lastUpdated: "20 February 2026",
    links: [
      { label: "Download 360p", url: "https://dl2.biggshare.xyz/Moviesda.Mobi_-_Lucky_the_Superstar_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://dl8.biggshare.xyz/Moviesda.Mobi_-_Lucky_the_Superstar_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://dl10.biggshare.xyz/Moviesda.Mobi_-_Lucky_the_Superstar_2026_Original_1080p_HD__3.3_GB_.mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.earth_-_Paathirathri_2025_Malayalam_TRUE_WEB-DL_-_4K_SDR_-_2160p_HQ_-_HEVC-_DD5.1_ATMOS_-_448Kbps__AAC_2.0.mkv?token=518e8e71e91154b366af33f4269affad&exp=1779989540", className: "K4" }
    ],
    watchUrl: "https://dl10.biggshare.xyz/Moviesda.Mobi_-_Lucky_the_Superstar_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Baby Girl (2025)",
    image: "https://imgs.search.brave.com/RNR7E5ffox7jdaYW-CH5lSkW9cZB8LvE4hJQsoji6O4/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL00v/TVY1QlltWmtNVGcw/T0RJdE9HUmtPUzAw/WWpaakxXRmlNRGN0/TldGa1lqWmxObU13/TW1GalhrRXlYa0Zx/Y0djQC5qcGc",
    movieName: "Baby Girl (2025)",
    director: "Arun Varma KP",
    starring: "Nivin Pauly, Lijomol Jose, Jaffer Idukki",
    genres: ["Drama", "Family", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.3/10",
    lastUpdated: "18 February 2026",
    links: [
      { label: "Download 360p", url: "https://s03.hotshare.link/Baby_Girl_2025_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s06.hotshare.link/Moviesda.Mobi_-_Baby_Girl_2025_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://dl10.biggshare.xyz/Baby_Girl_2025_Original_1080p_HD__3.4_GB_.mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.earth_-_Baby_Girl_2025_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_Tam__Tel__Kan_-_DD5.1_-_256Kbps__AAC_-_6GB_-_ESub.mkv?token=b703f29b27af0bc0d40fa2896e3909ea&exp=1779989613", className: "K4" }
    ],
    watchUrl: "https://s09.hotshare.link/Moviesda.Mobi_-_Baby_Girl_2025_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "LipLock (2026)",
    image: "https://imgs.search.brave.com/dttJB0Ix4_r9eD0q7qeUEFiE_gX2hCkXbxjrZ0znjlI/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tb3Zp/ZXB1ZmYuY29tL3dw/LWNvbnRlbnQvdXBs/b2Fkcy8yMDI2LzAy/L2ltYWdlcy0zLmpw/Zw",
    movieName: "LipLock (2026)",
    director: "Aghilan Maruthamuthu",
    starring: "Adithya R.K, Adithya Kathir, Niranjana",
    genres: ["Romantic", "Drama"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.3/10",
    lastUpdated: "15 February 2026",
    links: [
      { label: "Download 360p", url: "https://s13.cdnserver02.xyz/Moviesda.Mobi_-_LipLock_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s15.cdnserver02.xyz/Moviesda.Mobi_-_LipLock_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s14.cdnserver02.xyz/Moviesda.Mobi_-_LipLock_2026_Original_1080p_HD_(1.3_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.gs_-_LipLock_2026_Tamil_WEB-DL_-_4K_SDR_-_2160p_HQ_-_UNTOUCHED_-_AAC5.1_-_384Kbps_-_5.2GB_-_ESub.mkv?token=8e94a0948d9d50fb76ae33d2b53e0d0a&exp=1779989748", className: "K4" }
    ],
    watchUrl: "https://s14.cdnserver02.xyz/Moviesda.Mobi_-_LipLock_2026_Original_1080p_HD_(1.3_GB).mp4?stream=1"
  },
  {
    title: "Sweety Naughty Crazy (2026)",
    image: "https://imgs.search.brave.com/ARqXl5de4AxAxExvUEg9mo-pI9QqAJdGKGEaNK8faCg/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL00v/TVY1QlpqUmpZek5r/WW1VdE9Ea3haaTAw/TUdGaUxUaGlabUl0/TkdWak5HTTFZemM0/TWpJeVhrRXlYa0Zx/Y0djQC5qcGc",
    movieName: "Sweety Naughty Crazy (2026)",
    director: "Rajasekar G.",
    starring: "Thrigun A, Srijitaa Ghosh, Iniya",
    genres: ["Comedy", "Drama", "Romantic"],
    quality: "HQ PreDVD",
    language: "Tamil",
    rating: "9.4/10",
    lastUpdated: "14 February 2026",
    links: [
      { label: "Download 360p", url: "https://s01.cdnserver01.xyz/Sweety_Naughty_Crazy_2026_HQ_PreDVD_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s04.cdnserver01.xyz/Sweety_Naughty_Crazy_2026_HQ_PreDVD_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s01.cdnserver01.xyz/Sweety_Naughty_Crazy_2026_HQ_PreDVD_1080p_HD.mp4", className: "p1080" }
    ],
    watchUrl: "https://s01.cdnserver01.xyz/Sweety_Naughty_Crazy_2026_HQ_PreDVD_1080p_HD.mp4?stream=1"
  },
  {
    title: "Kombuseevi (2025)",
    image: "https://imgs.search.brave.com/Cxaab1wwKGu0K7WEwKWFU4jtOie99UEA5ZdVP45LwYI/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL00v/TVY1Qk9EUmlOREE1/WXpndFlUWTFaUzAw/WXprMUxUaG1ZV0l0/TjJJNE1EaGxaakkx/WmpRelhrRXlYa0Zx/Y0djQC5qcGc",
    movieName: "Kombuseevi (2025)",
    director: "Ponram",
    starring: "Shanmuga Pandian, R. Sarathkumar, Tharnika Rao",
    genres: ["Action", "Crime", "Drama"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.0/10",
    lastUpdated: "13 February 2026",
    links: [
      { label: "Download 360p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPWNmNTFkNzQ4NDdmNzljODA1NjQ4ZTJhOTA3YzlmYmYxJmV4cD0xNzc5ODUxOTAxJnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvS29tYnVzZWV2aSAoMjAyNSkvS29tYnVzZWV2aSAoT3JpZ2luYWwpL0tvbWJ1c2VldmkgKDM2MHAgSEQpL01vdmllc2RhLk1vYmkgLSBLb21idXNlZXZpIDIwMjUgT3JpZ2luYWwgMzYwcCBIRC5tcDQ=", className: "p480" },
      { label: "Download 720p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPWY3OWQxYzdmMDE5MzFmMjRjZmViZmE4ZTRhMDRhMmNhJmV4cD0xNzc5ODUxOTQyJnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvS29tYnVzZWV2aSAoMjAyNSkvS29tYnVzZWV2aSAoT3JpZ2luYWwpL0tvbWJ1c2VldmkgKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBLb21idXNlZXZpIDIwMjUgT3JpZ2luYWwgNzIwcCBIRC5tcDQ=", className: "p720" },
      { label: "Download 1080p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPWM5ZDU5M2VmYzUwOWRkZGE4MTY0ZDk1ZGFjNjA4N2FjJmV4cD0xNzc5ODUxOTY0JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvS29tYnVzZWV2aSAoMjAyNSkvS29tYnVzZWV2aSAoT3JpZ2luYWwpL0tvbWJ1c2VldmkgKDEwODBwIEhEKS9Nb3ZpZXNkYS5Nb2JpIC0gS29tYnVzZWV2aSAyMDI1IE9yaWdpbmFsIDEwODBwIEhEICgzLjUgR0IpLm1wNA==", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.rsvp_-_Kombuseevi_2025_Tamil_TRUE_WEB-DL_-_1080p_-_AVC_-_UNTOUCHED_-_DD5.1_-_448Kbps__AAC_2.0_-_8.7GB_-_ESub.mkv?token=583f05941a09616290ca04de09f76fb2&exp=1779989852", className: "K4" }
    ],
    watchUrl: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTVkNzE2YjkxZTIxOTQ5Nzg5MWViNmIwNzVlNGJhZDFmJmV4cD0xNzc5OTM2NjkzJnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvS29tYnVzZWV2aSAoMjAyNSkvS29tYnVzZWV2aSAoT3JpZ2luYWwpL0tvbWJ1c2VldmkgKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBLb21idXNlZXZpIDIwMjUgT3JpZ2luYWwgNzIwcCBIRC5tcDQ=&stream=1"
  },
  {
    title: "Thalaivar Thambi Thalaimaiyil (2026)",
    image: "https://imgs.search.brave.com/uwbrOH4MFt5snqBtMN3ldsahczyHiPQE1ZyIV1VtkQo/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9hc3Nl/dHMtaW4uYm1zY2Ru/LmNvbS9pZWRiL21v/dmllcy9pbWFnZXMv/bW9iaWxlL3RodW1i/bmFpbC94bGFyZ2Uv/dGhhbGFpdmFyLXRo/YW1iaS10aGFsYWlt/YWl5aWwtZXQwMDQ4/MTI1MS0xNzY4Mzcw/MTI2LmpwZw",
    movieName: "Thalaivar Thambi Thalaimaiyil (2026)",
    director: "Nithish Sahadev",
    starring: "Jiiva, Ilavarasu, Thambi Ramaiah",
    genres: ["Comedy", "Drama", "Family"],
    quality: "Original HD",
    language: "Tamil",
    rating: "6.8/10",
    lastUpdated: "12 February 2026",
    links: [
      { label: "Download 360p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Thalaivar_Thambi_Thalaimaiyil_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s23.cdnserver03.xyz/Moviesda.Mobi_-_Thalaivar_Thambi_Thalaimaiyil_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s24.cdnserver03.xyz/Moviesda.Mobi_-_Thalaivar_Thambi_Thalaimaiyil_2026_Original_1080p_HD_(3.4_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.rsvp_-_Thalaivar_Thambi_Thalaimaiyil_2026_TRUE_WEB-DL_-_1080p_-_A_-_Tam__Tel__Mal__Kan_-_DD5.1_-_640Kbps__AAC_-_6.2GB_-_ESub.mkv?token=1ec73af0304a0faf8b7b37208e5ac201&exp=1779989953", className: "K4" }
    ],
    watchUrl: "https://s24.cdnserver03.xyz/Moviesda.Mobi_-_Thalaivar_Thambi_Thalaimaiyil_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Parasakthi (2026)",
    image: "https://imgs.search.brave.com/AkY2q2ow9prhAzhZWB-9Y7aXEkGo_q-K9JnDwL_xo-A/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9wcmV2/aWV3LnJlZGQuaXQv/cGFyYXNha3RoaS0y/MDI2LW5vdy1zdHJl/YW1pbmctb24temVl/NS12MC1qdzdwZDZm/YmZ6aGcxLmpwZWc_/d2lkdGg9NjQwJmNy/b3A9c21hcnQmYXV0/bz13ZWJwJnM9OGZh/NzZkZmQ5OWE1Mjc0/NGRhZDYzODg0OWVm/ZTM1NDdjMDVhOTdl/ZQ",
    movieName: "Parasakthi (2026)",
    director: "Sudha Kongara Prasad",
    starring: "Sivakarthikeyan, Sree Leela, Jayam Ravi, Atharvaa",
    genres: ["Action", "Drama", "Period", "Political"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.9/10",
    lastUpdated: "07 February 2026",
    links: [
      { label: "Download 360p", url: "https://s32.cdnserver04.xyz/Moviesda.Mobi_-_Parasakthi_2026_Uncensored_Version_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_Parasakthi_2026_Uncensored_Version_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s32.cdnserver04.xyz/Moviesda.Mobi_-_Parasakthi_2026_Uncensored_Version_Original_1080p_HD_(3.3_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.rsvp_-_Parasakthi_2026_Tamil_Uncensored_Version_TRUE_WEB-DL_-_4K_SDR_-_2160p_HQ_-_HEVC_-_DD5.1_-_192Kbps__AAC_2.0.mkv?token=98aa781a97790a95af8e30f33c7562c0&exp=1779990048", className: "K4" }
    ],
    watchUrl: "https://s34.cdnserver04.xyz/Moviesda.Mobi_-_Parasakthi_2026_Uncensored_Version_Original_1080p_HD_(3.3_GB).mp4?stream=1"
  },
  {
    title: "IPL Indian Penal Law (2025)",
    image: "https://imgs.search.brave.com/utWCbEgNNs5xwYaB1LsVQdTAmAA7re3Co9pd_LbqjOA/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9hc3Nl/dHMtaW4uYm1zY2Ru/LmNvbS9pZWRiL21v/dmllcy9pbWFnZXMv/bW9iaWxlL3RodW1i/bmFpbC94bGFyZ2Uv/aXBsLWluZGlhbi1w/ZW5hbC1sYXctZXQw/MDQ3MTk5NC0xNzYz/NzIyMTI4LmpwZw",
    movieName: "IPL Indian Penal Law (2025)",
    director: "Karunanithi",
    starring: "TTF Vasan, Kishore Kumar G., Abhirami Gopikumar",
    genres: ["Crime", "Political", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "7.5/10",
    lastUpdated: "07 February 2026",
    links: [
      { label: "Download 360p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTkzOGMwMTQ3MTM3NzdiZWFmMWJjN2Y3ZDUwOTJiYTQ0JmV4cD0xNzc5ODUyNjQ2JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvSVBMIEluZGlhbiBQZW5hbCBMYXcgKDIwMjUpL0lQTCBJbmRpYW4gUGVuYWwgTGF3IChPcmlnaW5hbCkvSVBMIEluZGlhbiBQZW5hbCBMYXcgKDM2MHAgSEQpL01vdmllc2RhLk1vYmkgLSBJUEwgSW5kaWFuIFBlbmFsIExhdyAyMDI1IE9yaWdpbmFsIDM2MHAgSEQubXA0", className: "p480" },
      { label: "Download 720p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoSpecNDEzY2JiMjFjMGIzMzNkNDc5NDdlYTMzNzIwNWVkJmV4cD0xNzc5ODUyNjgxJnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvSVBMIEluZGlhbiBQZW5hbCBMYXcgKDIwMjUpL0lQTCBJbmRpYW4gUGVuYWwgTGF3IChPcmlnaW5hbCkvSVBMIEluZGlhbiBQZW5hbCBMYXcgKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBJUEwgSW5kaWFuIFBlbmFsIExhdyAyMDI1IE9yaWdpbmFsIDcyMHAgSEQubXA0", className: "p720" },
      { label: "Download 1080p", url: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTVlOWEyZDhkYjljYTRkYmU5N2MzZWY1MjE3YzU1OTAzJmV4cD0xNzc5ODUyNzA1JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvSVBMIEluZGlhbiBQZW5hbCBMYXcgKDIwMjUpL0lQTCBJbmRpYW4gUGVuYWwgTGF3IChPcmlnaW5hbCkvSVBMIEluZGlhbiBQZW5hbCBMYXcgKDEwODBwIEhEKS9Nb3ZpZXNkYS5Nb2JpIC0gSVBMIEluZGlhbiBQZW5hbCBMYXcgMjAyNSBPcmlnaW5hbCAxMDgwcCBIRCAoMy40IEdCKS5tcDQ=", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.rsvp_-_IPL_Indian_Penal_Law_2025_Tamil_TRUE_WEB-DL_-_4K_SDR_-_HEVC_-_DD5.1_-_512Kbps__AAC_-_11GB_-_ESub.mkv?token=9ce0001003ae06fc119df2e324c04271&exp=1779990110", className: "K4" }
    ],
    watchUrl: "https://cdn.uptomkv.ch/download.php?dl=c2VydmVyPW12MSZoYXNoPTAwZjUyYWI2MTRhODYyZjdiM2FjYzc3ZjUyYWEzMGZiJmV4cD0xNzc5OTM2ODI0JnBhdGg9VGFtaWwgMjAyNSBNb3ZpZXMvSVBMIEluZGlhbiBQZW5hbCBMYXcgKDIwMjUpL0lQTCBJbmRpYW4gUGVuYWwgTGF3IChPcmlnaW5hbCkvSVBMIEluZGlhbiBQZW5hbCBMYXcgKDcyMHAgSEQpL01vdmllc2RhLk1vYmkgLSBJUEwgSW5kaWFuIFBlbmFsIExhdyAyMDI1IE9yaWdpbmFsIDcyMHAgSEQubXA0&stream=1"
  },
  {
    title: "The Raja Saab (2026)",
    image: "https://imgs.search.brave.com/GDLV-7kpAHE-SR0izDuq4BqhNYETAgiLs5m0n0r9RIc/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9wcmV2/aWV3LnJlZGQuaXQv/dGhlLXJhamEtc2Fh/Yi0yMDI2LXJldmll/dy1kaXNjdXNzaW9u/LXRocmVhZC1zcG9p/bGVycy1tdXN0LXYw/LWJoZ3VqOWg2dWFj/ZzEucG5nP3dpZHRo/PTEwODAmZm9ybWF0/PXBuZyZhdXRvPXdl/YnAmcz02NzQ2OTQ1/ZWJmYzQ3OTdiMTM0/ODg2ZjkyYzQ4YmM5/NzFlODlhYzVl",
    movieName: "The Raja Saab (2026)",
    director: "Maruthi Dasari",
    starring: "Prabhas, Sanjay Dutt, Boman Irani",
    genres: ["Comedy", "Horror", "Romantic"],
    quality: "Original HD",
    language: "Tamil",
    rating: "8.1/10",
    lastUpdated: "06 February 2026",
    links: [
      { label: "Download 360p", url: "https://s25.cdnserver03.xyz/Moviesda.Mobi_-_The_Raja_Saab_2026_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s02.cdnserver01.xyz/Moviesda.Mobi_-_The_Raja_Saab_2026_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://s22.cdnserver03.xyz/Moviesda.Mobi_-_The_Raja_Saab_2026_Original_1080p_HD_(3.4_GB).mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.rsvp_-_The_Raja_Saab_2026_TRUE_WEB-DL_-_1080p_-_AVC_-_Tam__Tel__Mal__Kan_-_DD5.1_ATMOS_-_768Kbps__AAC_-_8.2GB_-_ESub.mkv?token=ddc496b6054837d6a2b25fcf23c724ac&exp=1779990160", className: "K4" }
    ],
    watchUrl: "https://s04.cdnserver01.xyz/Moviesda.Mobi_-_The_Raja_Saab_2026_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Sarvam Maya (2025)",
    image: "https://imgs.search.brave.com/K9IGOAYaa1Gmjvq9mhQd9YazhgM7veZ7erRxUoxtuaQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pLnBp/bmltZy5jb20vb3Jp/Z2luYWxzL2NjLzUw/LzkzL2NjNTA5M2M0/NGY4NmE5N2MyOWE4/MDA1MjUxMzI2M2Zk/LmpwZw",
    movieName: "Sarvam Maya (2025)",
    director: "Akhil Sathyan",
    starring: "Nivin Pauly, Aju Varghese, Janardhanan",
    genres: ["Comedy", "Drama", "Fantasy"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.2/10",
    lastUpdated: "30 January 2026",
    links: [
      { label: "Download 360p", url: "https://dl10.biggshare.xyz/Sarvam_Maya_2025_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://s05.hotshare.link/Sarvam_Maya_2025_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://dl8.biggshare.xyz/Sarvam_Maya_2025_Original_1080p_HD__3.4_GB_.mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.rsvp_-_Sarvam_Maya_2025_TRUE_WEB-DL_-_4K_SDR_-_2160p_HQ_-_HEVC_-_UNTOUCHED_-_TAM__TEL__HIN__MAL__KAN.mkv?token=5483ec8d65e7c601699553e88725a7aa&exp=1779990253", className: "K4" }
    ],
    watchUrl: "https://dl5.biggshare.xyz/Sarvam_Maya_2025_Original_720p_HD.mp4?stream=1"
  },
  {
    title: "Dhurandhar (2025)",
    image: "https://imgs.search.brave.com/W4VdUCH9UrWud4CfI4Chgu8xiphBLmOmN78fbWtIOaM/rs:fit:500:0:1:0/g:ce/aHR0cDovL3d3dy5p/bXBhd2FyZHMuY29t/L2ludGwvaW5kaWEv/MjAyNS9wb3N0ZXJz/L2RodXJhbmRoYXIu/anBn",
    movieName: "Dhurandhar (2025)",
    director: "Aditya Dhar",
    starring: "Ranveer Singh, Akshaye Khanna, Sanjay Dutt",
    genres: ["Action", "Thriller"],
    quality: "Original HD",
    language: "Tamil",
    rating: "9.3/10",
    lastUpdated: "01 February 2026",
    links: [
      { label: "Download 360p", url: "https://dl2.biggshare.xyz/Moviesda.Mobi_-_Dhurandhar_2025_Original_360p_HD.mp4", className: "p480" },
      { label: "Download 720p", url: "https://dl3.biggshare.xyz/Moviesda.Mobi_-_Dhurandhar_2025_Original_720p_HD.mp4", className: "p720" },
      { label: "Download 1080p", url: "https://dl10.biggshare.xyz/Moviesda.Mobi_-_Dhurandhar_2025_Original_1080p_HD__3.2_GB_.mp4", className: "p1080" },
      { label: "Download 4K", url: "https://cdn.juicybits.site/files/www.1TamilMV.rsvp_-_Dhurandhar_2025_V2_WEB-DL_-_1080p_-_AVC_-_Tamil__Telugu__Hindi_-_DD5.1_-_640Kbps__AAC_2.0_-_10GB_-_ESub.mkv?token=e69b126690db22e73c6b3a806a91cef8&exp=1779990314", className: "K4" }
    ],
    watchUrl: "https://dl6.biggshare.xyz/Moviesda.Mobi_-_Dhurandhar_2025_Original_720p_HD.mp4?stream=1"
  }
];
