import React, { useState } from "react";
import { Plus, ListCollapse, MessageSquare, Send, CheckCircle, Sparkles, Star } from "lucide-react";

interface CommunityRequest {
  id: number;
  movie: string;
  year: string;
  language: string;
  user: string;
  timeLabel: string;
  status: "Uploaded" | "Under Review" | "Approved";
  comments?: string;
}

export default function RequestSection() {
  // Mock Community requests database to represent "Request movie section" beautifully
  const [requests, setRequests] = useState<CommunityRequest[]>([
    { id: 1, movie: "Surya 44 (2026)", year: "2026", language: "Tamil", user: "Prabu R.", timeLabel: "8 minutes ago", status: "Approved", comments: "Awaiting high quality mirror audio release" },
    { id: 2, movie: "SK 23 (2026)", year: "2026", language: "Tamil", user: "Mohanraj K.", timeLabel: "2 hours ago", status: "Under Review" },
    { id: 3, movie: "Thalapathy 69 (2026)", year: "2026", language: "Tamil", user: "Vignesh Kumar", timeLabel: "5 hours ago", status: "Uploaded" },
    { id: 4, movie: "Mark (4K Request)", year: "2025", language: "Dual Audio [Tamil + English]", user: "Suresh P.", timeLabel: "1 day ago", status: "Uploaded" },
  ]);

  const [movieName, setMovieName] = useState("");
  const [year, setYear] = useState("");
  const [genre, setGenre] = useState("Action");
  const [language, setLanguage] = useState("Tamil");
  const [comments, setComments] = useState("");
  
  // Custom inside-app notification toast to avoid blocked window.alerts
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!movieName.trim()) {
      return;
    }

    // Add locally to request board list
    const newReq: CommunityRequest = {
      id: Date.now(),
      movie: movieName + (year ? ` (${year})` : ""),
      year: year || "2026",
      language,
      user: "You",
      timeLabel: "Just now",
      status: "Approved",
      comments: comments.trim() ? comments : undefined
    };

    setRequests([newReq, ...requests]);
    setSuccessToast(`"${movieName}" requested successfully! Community moderators have updated status to Approved.`);
    
    // Clear state inputs
    setMovieName("");
    setYear("");
    setGenre("Action");
    setLanguage("Tamil");
    setComments("");

    setTimeout(() => {
      setSuccessToast(null);
    }, 5000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      
      {/* Interactive Form glass terminal container */}
      <div className="lg:col-span-7 rounded-3xl glass-panel p-4 xs:p-5 sm:p-6 border border-white/5 space-y-6 relative overflow-hidden box-glow-red">
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-650/5 rounded-full blur-2xl" />
        
        <div>
          <h3 className="font-display font-black text-xl sm:text-2xl text-white tracking-tight flex items-center gap-2">
            <Plus className="text-red-500 text-neon-red" size={24} />
            Request Movie Arena
          </h3>
          <p className="text-xs sm:text-sm text-gray-400 mt-1 max-w-xl">
            Can't find a particular classic, audio launch show, or recent blockbuster? Send a ticket request! Our streaming nodes gather high quality prints within 24 hours.
          </p>
        </div>

        {/* Dynamic Inner Success custom Alert notification popups */}
        {successToast && (
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs sm:text-sm flex items-start gap-2.5 animate-fadeIn">
            <CheckCircle size={18} className="shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Ticket Submitted!</p>
              <p className="opacity-90 mt-0.5">{successToast}</p>
            </div>
          </div>
        )}

        {/* HTML form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Movie Title */}
            <div className="space-y-1.5 col-span-1 sm:col-span-2">
              <label className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider">Movie / Series Name:</label>
              <input
                type="text"
                required
                value={movieName}
                onChange={(e) => setMovieName(e.target.value)}
                placeholder="e.g. Amaravathi, Singam, Surya 44"
                className="w-full px-4 py-3 rounded-xl bg-white/4 focus:bg-[#0c0c14] border border-white/5 focus:border-red-500/50 outline-none text-white text-sm transition-all duration-300"
              />
            </div>

            {/* Launch Year */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider">Release Year:</label>
              <input
                type="text"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                placeholder="e.g. 2026, 1999"
                className="w-full px-4 py-3 rounded-xl bg-white/4 focus:bg-[#0c0c14] border border-white/5 focus:border-red-500/50 outline-none text-white text-sm transition-all duration-300"
              />
            </div>

            {/* Select Primary Language option */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider">Language Feed:</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-white/4 focus:bg-[#0c0c14] border border-white/5 focus:border-red-500/55 outline-none text-white text-sm transition-all duration-300 [&>option]:bg-neutral-900"
              >
                <option value="Tamil">Original Tamil</option>
                <option value="Dual Audio [Tamil+Hindi]">Dual [Tamil + Hindi]</option>
                <option value="Dual Audio [Tamil+English]">Dual [Tamil + English]</option>
                <option value="Multi-Audio [5 Languages]">Multi-Audio [5 Languages]</option>
              </select>
            </div>

          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Gener filter category selection link */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider">Primary Genre:</label>
              <select
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-white/4 focus:bg-[#0c0c14] border border-white/5 focus:border-red-500/55 outline-none text-white text-sm transition-all duration-300 [&>option]:bg-neutral-900"
              >
                <option value="Action">Action / Thriller</option>
                <option value="Comedy">Comedy</option>
                <option value="Drama">Drama / Family</option>
                <option value="Mystery">Mystery / Supernatural</option>
                <option value="Romantic">Romantic</option>
              </select>
            </div>

            {/* Optional Comment message inputs */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider">Requested Quality:</label>
              <select 
                className="w-full px-4 py-3 rounded-xl bg-white/4 focus:bg-[#0c0c14] border border-white/5 focus:border-red-500/55 outline-none text-white text-sm transition-all duration-300 [&>option]:bg-neutral-900"
              >
                <option>Original HD (Recommended)</option>
                <option>4K Ultra HD (HEVC/HDR)</option>
                <option>1080p HQ audio</option>
              </select>
            </div>

          </div>

          {/* Special request comments area */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider">Additional details or comments:</label>
              <span className="text-[10px] text-gray-500 font-mono">Optional</span>
            </div>
            <textarea
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              placeholder="e.g. Please upload the dual-audio 5.1 surrounds version if available..."
              className="w-full px-4 py-3 rounded-xl bg-white/4 focus:bg-[#0c0c14] border border-white/5 focus:border-red-500/50 outline-none text-white text-sm h-24 resize-none transition-all duration-300"
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 rounded-xl bg-red-650 hover:bg-red-550 border border-red-500/30 text-white font-display font-semibold transition-all duration-300 shadow-[0_0_20px_rgba(239,68,68,0.25)] flex items-center justify-center gap-2 cursor-pointer group"
          >
            <Send size={15} className="group-hover:translate-x-1 group-hover:-translate-y-0.5 transition-transform" />
            <span>Launch Request Ticket</span>
          </button>
        </form>
      </div>

      {/* Community Demand Live Ledger */}
      <div className="lg:col-span-5 rounded-3xl glass-panel p-4 xs:p-5 sm:p-6 border border-white/5 space-y-4">
        <div>
          <h4 className="font-display font-bold text-lg text-white uppercase tracking-tight flex items-center gap-2">
            <ListCollapse size={18} className="text-blue-400" />
            Community Ledger
          </h4>
          <p className="text-[11px] text-gray-500 mt-0.5">
            Active demand boards currently reviewed by portal seeding encoders:
          </p>
        </div>

        {/* Live List Container */}
        <div className="space-y-3.5 max-h-[460px] overflow-y-auto pr-1">
          {requests.map((r) => (
            <div 
              key={r.id}
              className="p-3.5 rounded-xl bg-black/40 border border-white/5 hover:border-white/10 transition-colors space-y-2 relative group"
            >
              {/* Badge label state indicators */}
              <div className="absolute right-3 top-3.5">
                <span className={`text-[9px] font-mono font-black px-2 py-0.5 rounded-full border tracking-wide uppercase ${
                  r.status === "Uploaded"
                    ? "bg-blue-650/20 text-blue-400 border-blue-500/30"
                    : r.status === "Approved"
                    ? "bg-red-600/20 text-red-500 border-red-500/30"
                    : "bg-amber-500/10 text-amber-500 border-amber-500/20 animate-pulse"
                }`}>
                  {r.status}
                </span>
              </div>

              <div>
                <h5 className="font-display font-bold text-sm text-gray-200 line-clamp-1 pr-16">{r.movie}</h5>
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[10px] text-gray-500 mt-1 font-semibold">
                  <span className="text-gray-400">{r.user}</span>
                  <span>•</span>
                  <span>{r.language}</span>
                  <span>•</span>
                  <span>{r.timeLabel}</span>
                </div>
              </div>

              {r.comments && (
                <div className="p-2 rounded bg-white/2 border-l-2 border-red-500 text-[11px] text-gray-400 italic">
                  "{r.comments}"
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="pt-2">
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-red-600/5 to-blue-600/5 border border-red-500/10 flex items-center gap-3">
            <Star size={16} className="text-amber-400 shrink-0" />
            <span className="text-[10px] sm:text-xs text-gray-400 leading-relaxed">
              Every request automatically increments download bandwidth prioritization metrics on primary seeding clusters.
            </span>
          </div>
        </div>

      </div>

    </div>
  );
}
