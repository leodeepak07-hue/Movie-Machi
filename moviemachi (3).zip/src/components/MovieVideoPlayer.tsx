import { useState, useEffect, useRef, MouseEvent, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Play, Pause, Volume2, VolumeX, Maximize, X, 
  Film, SkipForward, ArrowRight, Activity, CornerDownLeft, Sparkles, Check,
  Rewind, FastForward, SkipBack, Settings, Minimize2, Volume1, Laptop
} from "lucide-react";
import { Movie } from "../types";

interface VideoPlayerProps {
  movie: Movie | null;
  onClose: () => void;
  onProgress?: (progress: number) => void;
  isTrailer?: boolean;
}

export default function MovieVideoPlayer({ movie, onClose, isTrailer }: VideoPlayerProps) {
  if (!movie) return null;

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Performance optimization refs
  const volumeTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastSavedTimeRef = useRef<number>(0);
  const currentTimeRef = useRef<number>(0);

  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [audioTrack, setAudioTrack] = useState("Original (Tamil)");
  const [showVolumeBadge, setShowVolumeBadge] = useState(false);
  
  // Custom interactive layout & auto-hide states
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLayoutFullscreen, setIsLayoutFullscreen] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverX, setHoverX] = useState<number>(0);

  // Ambient state restoration
  const [ambientLights, setAmbientLights] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("moviemachi_ambient_glow");
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  const [glowColor, setGlowColor] = useState("rgba(239, 68, 68, 0.35)");

  const getGlowWithAlpha = (alpha: number) => {
    try {
      const rgb = glowColor.match(/\d+/g);
      if (rgb && rgb.length >= 3) {
        return `rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${alpha})`;
      }
    } catch (e) {}
    return glowColor;
  };

  // Resume & Movie Start Dialog states
  const [showStartPopup, setShowStartPopup] = useState(false);
  const [savedResumeTime, setSavedResumeTime] = useState(0);

  // Fallback trailer links if movie doesn't have custom watchUrl
  const fallbackVideoUrl = "https://assets.mixkit.co/videos/preview/mixkit-curious-cat-watching-tv-40847-large.mp4";
  const sourceUrl = isTrailer 
    ? (movie.trailerUrl || movie.watchUrl || fallbackVideoUrl) 
    : (movie.watchUrl || fallbackVideoUrl);

  // Convert seconds to readable track time HH:MM:SS
  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs === Infinity || secs < 0) return "00:00:00";
    const hrs = Math.floor(secs / 3600);
    const mins = Math.floor((secs % 3600) / 60);
    const remaining = Math.floor(secs % 60);
    const pad = (num: number) => num < 10 ? `0${num}` : num.toString();
    return `${pad(hrs)}:${pad(mins)}:${pad(remaining)}`;
  };

  // Sync fullscreen change event
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, []);

  // Sync auto-hide timers based on isPlaying activity
  const resetControlsTimeout = () => {
    setControlsVisible(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setControlsVisible(false);
        setShowSettingsMenu(false);
      }
    }, 4000); // 4 seconds auto-hide when playing
  };

  useEffect(() => {
    if (isPlaying) {
      resetControlsTimeout();
    } else {
      setControlsVisible(true);
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    }
    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    };
  }, [isPlaying]);

  const handleUserInteraction = () => {
    resetControlsTimeout();
  };

  const handleVideoClick = (e: MouseEvent) => {
    e.stopPropagation();
    if (!controlsVisible) {
      setControlsVisible(true);
      resetControlsTimeout();
    } else {
      togglePlay();
    }
  };

  // Extract Dominant Accent Colors for Ambient Aura Glow (Performance Optimized)
  useEffect(() => {
    if (!ambientLights || !isPlaying || !videoRef.current) return;

    if (!canvasRef.current) {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = 16;
        canvas.height = 16;
        canvasRef.current = canvas;
      } catch (e) {}
    }

    const intervalId = setInterval(() => {
      const video = videoRef.current;
      if (!video || video.paused || video.ended) return;

      try {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        if (ctx) {
          ctx.drawImage(video, 0, 0, 16, 16);
          const imgData = ctx.getImageData(0, 0, 16, 16).data;
          let r = 0, g = 0, b = 0, count = 0;
          for (let i = 0; i < imgData.length; i += 4) {
            r += imgData[i];
            g += imgData[i + 1];
            b += imgData[i + 2];
            count++;
          }
          if (count > 0) {
            r = Math.round(r / count);
            g = Math.round(g / count);
            b = Math.round(b / count);
            // Apply vibrant cinematic representation
            setGlowColor(`rgba(${r}, ${g}, ${b}, 0.35)`);
          }
        }
      } catch (err) {
        // Fallback smooth ambient spectrum colors
        const fallbacks = [
          "rgba(239, 68, 68, 0.35)", // soft red
          "rgba(37, 99, 235, 0.35)", // soft blue
          "rgba(139, 92, 246, 0.35)", // soft purple
          "rgba(245, 158, 11, 0.35)"  // soft amber
        ];
        const randomColor = fallbacks[Math.floor(Math.random() * fallbacks.length)];
        setGlowColor(randomColor);
      }
    }, 2000);

    return () => clearInterval(intervalId);
  }, [ambientLights, isPlaying, movie]);

  useEffect(() => {
    if (isTrailer) {
      setShowStartPopup(false);
      setSavedResumeTime(0);
      return;
    }
    try {
      const stored = localStorage.getItem("movie_progress") || "{}";
      const progressDb = JSON.parse(stored);
      const mProg = progressDb[movie.title];

      if (mProg && mProg.currentTime > 0) {
        setSavedResumeTime(mProg.currentTime);
        setShowStartPopup(true);
      } else {
        setShowStartPopup(false);
        setSavedResumeTime(0);
      }

      // Initialize if not exists
      if (!progressDb[movie.title]) {
        progressDb[movie.title] = {
          title: movie.title,
          image: movie.image,
          movieName: movie.movieName,
          quality: movie.quality,
          percent: 0,
          currentTime: 0,
          lastWatchedTime: "00:00:00",
          lastPlayed: new Date().toLocaleDateString()
        };
        localStorage.setItem("movie_progress", JSON.stringify(progressDb));
      }
    } catch (e) {
      console.warn("Storage write ignored: ", e);
    }
  }, [movie]);

  const handleResumeConfirm = () => {
    setShowStartPopup(false);
    if (videoRef.current) {
      videoRef.current.currentTime = savedResumeTime;
      setCurrentTime(savedResumeTime);
      videoRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(err => console.warn(err));
    }
  };

  const handleStartOverConfirm = () => {
    setShowStartPopup(false);
    try {
      const stored = localStorage.getItem("movie_progress") || "{}";
      const progressDb = JSON.parse(stored);
      if (progressDb[movie.title]) {
        progressDb[movie.title].percent = 0;
        progressDb[movie.title].currentTime = 0;
        progressDb[movie.title].lastWatchedTime = "00:00:00";
        localStorage.setItem("movie_progress", JSON.stringify(progressDb));
        window.dispatchEvent(new Event("storage"));
      }
    } catch (e) {}

    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      setCurrentTime(0);
      videoRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(err => console.warn(err));
    }
  };

  // Standard interactive hotkeys (Space, ArrowLeft, ArrowRight, escape, M, H, A)
  useEffect(() => {
    const handleHotKeys = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === "INPUT" ||
        document.activeElement?.tagName === "TEXTAREA"
      ) {
        return;
      }

      switch (e.key) {
        case " ":
          e.preventDefault();
          togglePlay();
          break;
        case "ArrowLeft":
          e.preventDefault();
          skipBackward();
          break;
        case "ArrowRight":
          e.preventDefault();
          skipForward();
          break;
        case "m":
        case "M":
          e.preventDefault();
          toggleMute();
          break;
        case "h":
        case "H": {
          e.preventDefault();
          const next = !ambientLights;
          setAmbientLights(next);
          try {
            localStorage.setItem("moviemachi_ambient_glow", JSON.stringify(next));
          } catch {}
          break;
        }
        case "a":
        case "A": {
          e.preventDefault();
          const list = ["Original (Tamil)", "Dual (Eng/Tam) Stereo", "DTS 5.1 Dolby"];
          const currIdx = list.indexOf(audioTrack);
          setAudioTrack(list[(currIdx + 1) % list.length]);
          break;
        }
        case "Escape":
          e.preventDefault();
          handleClose();
          break;
        default:
          break;
      }
    };

    window.addEventListener("keydown", handleHotKeys);
    return () => {
      window.removeEventListener("keydown", handleHotKeys);
    };
  }, [movie, duration, volume, isMuted, playbackSpeed, audioTrack, ambientLights]);

  // Synchronous progress saver for immediate state persistence on pause/seek/unload
  const saveProgressImmediately = () => {
    if (isTrailer) return;
    const curr = currentTimeRef.current;
    if (curr === 0 || duration <= 0) return;
    try {
      const stored = localStorage.getItem("movie_progress") || "{}";
      const progressDb = JSON.parse(stored);
      if (progressDb[movie.title]) {
        const calculatedPercent = Math.floor((curr / duration) * 100);
        
        if (calculatedPercent > 95) {
          progressDb[movie.title].percent = 0;
          progressDb[movie.title].currentTime = 0;
          progressDb[movie.title].lastWatchedTime = "00:00:00";
        } else {
          progressDb[movie.title].percent = Math.max(calculatedPercent, 1);
          progressDb[movie.title].currentTime = curr;
          progressDb[movie.title].lastWatchedTime = formatTime(curr);
        }
        progressDb[movie.title].lastPlayed = new Date().toLocaleDateString();
        localStorage.setItem("movie_progress", JSON.stringify(progressDb));
        window.dispatchEvent(new Event("storage"));
      }
    } catch (e) {
      console.warn(e);
    }
  };

  const handleClose = () => {
    saveProgressImmediately();
    onClose();
  };

  // Safe timer-based storage persistence of progress across mount lifecycles
  useEffect(() => {
    return () => {
      saveProgressImmediately();
      if (volumeTimeoutRef.current) {
        clearTimeout(volumeTimeoutRef.current);
      }
    };
  }, [movie, duration]);

  // Support for standard MP4/direct URLs and HLS .m3u8 streams via dynamic Hls.js loader
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let hlsInstance: any = null;

    if (sourceUrl && sourceUrl.toLowerCase().includes(".m3u8")) {
      // Clear native source attribute to avoid conflict
      video.removeAttribute("src");

      if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = sourceUrl;
      } else {
        const initHls = () => {
          if ((window as any).Hls) {
            const Hls = (window as any).Hls;
            if (Hls.isSupported()) {
              if (hlsInstance) {
                hlsInstance.destroy();
              }
              hlsInstance = new Hls();
              hlsInstance.loadSource(sourceUrl);
              hlsInstance.attachMedia(video);
            }
          }
        };

        if (!(window as any).Hls) {
          const script = document.createElement("script");
          script.src = "https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js";
          script.async = true;
          script.onload = initHls;
          document.body.appendChild(script);
        } else {
          initHls();
        }
      }
    } else {
      video.src = sourceUrl;
    }

    return () => {
      if (hlsInstance) {
        hlsInstance.destroy();
      }
    };
  }, [sourceUrl]);

  // Actual progress tracker (with Throttled local storage writing to prevent layout lags on Smart TV and Mobile)
  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const curr = videoRef.current.currentTime;
      setCurrentTime(curr);
      currentTimeRef.current = curr;

      if (isTrailer) return;

      // Persist exact progress to Continue Watching (Throttled to >= 5 seconds difference, or near-end)
      const isNearEnd = duration > 0 && curr > duration - 2;
      const shouldSave = Math.abs(curr - lastSavedTimeRef.current) >= 5 || isNearEnd;

      if (shouldSave) {
        lastSavedTimeRef.current = curr;
        try {
          const stored = localStorage.getItem("movie_progress") || "{}";
          const progressDb = JSON.parse(stored);
          if (progressDb[movie.title]) {
            const calculatedPercent = duration > 0 ? Math.floor((curr / duration) * 100) : 0;
            
            if (calculatedPercent > 95) {
              // Completion Reset (Clear saved timestamp and percentage)
              progressDb[movie.title].percent = 0;
              progressDb[movie.title].currentTime = 0;
              progressDb[movie.title].lastWatchedTime = "00:00:00";
            } else {
              progressDb[movie.title].percent = Math.max(calculatedPercent, 1);
              progressDb[movie.title].currentTime = curr;
              progressDb[movie.title].lastWatchedTime = formatTime(curr);
            }
            progressDb[movie.title].lastPlayed = new Date().toLocaleDateString();
            localStorage.setItem("movie_progress", JSON.stringify(progressDb));
            window.dispatchEvent(new Event("storage")); // Trigger reactive updates elsewhere
          }
        } catch (e) {
          // Safe skip
        }
      }
    }
  };

  const handleWaiting = () => {
    setIsLoading(true);
  };

  const handlePlaying = () => {
    setIsLoading(false);
    setIsPlaying(true);
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      const dur = videoRef.current.duration;
      setDuration(dur);
      setIsLoading(false);

      if (showStartPopup) {
        videoRef.current.currentTime = savedResumeTime;
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play().then(() => {
          setIsPlaying(true);
        }).catch((e) => {
           console.log("Autoplay blocked: ", e);
        });
      }
    }
  };

  const togglePlay = () => {
    // Hide startup resume popup if visible when toggling play
    if (showStartPopup) {
      setShowStartPopup(false);
    }
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play().then(() => {
          setIsPlaying(true);
        }).catch(() => {});
      }
    }
  };

  const handleSeek = (value: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = value;
      setCurrentTime(value);
      currentTimeRef.current = value;
      saveProgressImmediately(); // Save immediately when user seeks!
    }
  };

  const handleVolumeChange = (val: number) => {
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
      setIsMuted(val === 0);
    }
    setShowVolumeBadge(true);
    if (volumeTimeoutRef.current) {
      clearTimeout(volumeTimeoutRef.current);
    }
    volumeTimeoutRef.current = setTimeout(() => setShowVolumeBadge(false), 2000);
  };

  const toggleMute = () => {
    if (videoRef.current) {
      const nextMute = !isMuted;
      setIsMuted(nextMute);
      videoRef.current.muted = nextMute;
    }
  };

  const handleSpeedToggle = () => {
    const speeds = [1, 1.25, 1.5, 2];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    const nextSpeed = speeds[nextIdx];
    setPlaybackSpeed(nextSpeed);
    if (videoRef.current) {
      videoRef.current.playbackRate = nextSpeed;
    }
  };

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    try {
      if (!document.fullscreenElement) {
        if (containerRef.current.requestFullscreen) {
          await containerRef.current.requestFullscreen();
        } else if ((containerRef.current as any).webkitRequestFullscreen) { /* Safari */
          await (containerRef.current as any).webkitRequestFullscreen();
        }
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as any).webkitExitFullscreen) {
          await (document as any).webkitExitFullscreen();
        }
      }
    } catch (err) {
      console.warn("Fullscreen toggle failed, using sandbox layout fallback:", err);
      setIsLayoutFullscreen(prev => !prev);
    }
  };

  // Skip Ahead 10s
  const skipForward = () => {
    if (videoRef.current) {
      const nextTime = Math.min(videoRef.current.currentTime + 10, duration);
      videoRef.current.currentTime = nextTime;
      setCurrentTime(nextTime);
    }
  };

  // Back 10s
  const skipBackward = () => {
    if (videoRef.current) {
      const nextTime = Math.max(videoRef.current.currentTime - 10, 0);
      videoRef.current.currentTime = nextTime;
      setCurrentTime(nextTime);
    }
  };

  // Manual Resume Button inside player controls
  const handleResumeClick = () => {
    let saved = 0;
    try {
      const stored = localStorage.getItem("movie_progress") || "{}";
      const progressDb = JSON.parse(stored);
      const mProg = progressDb[movie.title];
      if (mProg && mProg.currentTime > 0) {
        saved = mProg.currentTime;
      }
    } catch (e) {}

    if (videoRef.current) {
      if (saved > 0) {
        videoRef.current.currentTime = saved;
        setCurrentTime(saved);
      } else {
        videoRef.current.currentTime = 0;
        setCurrentTime(0);
      }
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
      setShowStartPopup(false);
    }
  };

  // Progress Bar interactions
  const handleProgressBarMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current || duration <= 0) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const relX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, relX / rect.width));
    setHoverTime(percentage * duration);
    setHoverX(relX);
  };

  const handleProgressBarMouseLeave = () => {
    setHoverTime(null);
  };

  const handleProgressBarClick = (e: MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current || duration <= 0) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const relX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, relX / rect.width));
    handleSeek(percentage * duration);
  };

  // Memoized Sub-structures representing static visual elements to optimize rendering updates
  const ambientBackdropContent = useMemo(() => {
    return (
      <>
        {/* Subtle background blur behind the player */}
        <div className="absolute inset-0 bg-neutral-950/25 backdrop-blur-[6px]" />

        {/* 1. Large Central Aura (Pulsing halo) */}
        <div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] h-[95vh] rounded-full blur-[150px] opacity-75 transition-all duration-1000 mix-blend-screen" 
          style={{ 
            background: `radial-gradient(circle, ${getGlowWithAlpha(0.5)} 0%, rgba(0,0,0,0) 75%)`
          }}
        />

        {/* 2. Left Side Animated Light Bar */}
        <div 
          className="absolute left-0 top-[15%] bottom-[15%] w-[30vw] blur-[110px] opacity-80 rounded-r-3xl transition-all duration-1000 animate-pulse mix-blend-screen"
          style={{
            background: `linear-gradient(to right, ${getGlowWithAlpha(0.6)}, transparent)`,
            animationDuration: '3.5s'
          }}
        />

        {/* 3. Right Side Animated Light Bar */}
        <div 
          className="absolute right-0 top-[15%] bottom-[15%] w-[30vw] blur-[110px] opacity-80 rounded-l-3xl transition-all duration-1000 animate-pulse mix-blend-screen"
          style={{
            background: `linear-gradient(to left, ${getGlowWithAlpha(0.6)}, transparent)`,
            animationDuration: '4.2s'
          }}
        />

        {/* 4. Bottom Side Animated Light Bar */}
        <div 
          className="absolute bottom-0 left-[15%] right-[15%] h-[35vh] blur-[90px] opacity-85 rounded-t-3xl transition-all duration-1000 animate-pulse mix-blend-screen"
          style={{
            background: `linear-gradient(to top, ${getGlowWithAlpha(0.65)}, transparent)`,
            animationDuration: '2.8s'
          }}
        />

        {/* Floating light particles near player edges */}
        <div className="absolute inset-0 mix-blend-screen opacity-70">
          {/* Particle 1 - top left area */}
          <div 
            className="absolute w-3 h-3 rounded-full blur-[1px] transition-all duration-1000 animate-pulse" 
            style={{
              backgroundColor: getGlowWithAlpha(0.8),
              top: '18%',
              left: '12%',
              animationDuration: '3s'
            }}
          />
          {/* Particle 2 - bottom right area */}
          <div 
            className="absolute w-4 h-4 rounded-full blur-[1.5px] transition-all duration-1000 animate-ping" 
            style={{
              backgroundColor: getGlowWithAlpha(0.9),
              bottom: '22%',
              right: '15%',
              animationDuration: '4s'
            }}
          />
          {/* Particle 3 - bottom left area */}
          <div 
            className="absolute w-2.5 h-2.5 rounded-full blur-[0.8px] transition-all duration-1000 animate-pulse" 
            style={{
              backgroundColor: getGlowWithAlpha(0.6),
              bottom: '15%',
              left: '18%',
              animationDuration: '2.5s'
            }}
          />
          {/* Particle 4 - top right area */}
          <div 
            className="absolute w-3.5 h-3.5 rounded-full blur-[1.2px] transition-all duration-1000 animate-ping" 
            style={{
              backgroundColor: getGlowWithAlpha(0.85),
              top: '25%',
              right: '16%',
              animationDuration: '3.5s'
            }}
          />
        </div>
      </>
    );
  }, [glowColor]);

  const startOverDialogContent = useMemo(() => {
    if (!showStartPopup) return null;
    return (
      <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4">
        <motion.div 
          initial={{ scale: 0.9, y: 15 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 15 }}
          className="w-full max-w-sm p-4 sm:p-8 bg-[#09090f] border border-white/10 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] text-center space-y-3 sm:space-y-6 mx-auto max-h-[90vh] overflow-y-auto scrollbar-none"
        >
          <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-red-650/15 text-red-500 border border-red-500/20 flex items-center justify-center mx-auto animate-bounce/slow">
            <Film className="w-6 h-6 sm:w-7 sm:h-7" />
          </div>
          
          <div className="space-y-1 sm:space-y-2">
            <h3 className="font-display font-black text-lg sm:text-2xl text-white uppercase tracking-wider">
              Continue Watching?
            </h3>
            <p className="text-xs sm:text-sm text-gray-300 font-medium font-sans truncate">
              {movie.movieName}
            </p>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 sm:py-1.5 rounded-xl bg-white/5 border border-white/5 font-mono text-[10px] sm:text-xs text-red-400 font-bold">
              <span>Resume from:</span>
              <span>{formatTime(savedResumeTime)}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              onClick={handleResumeConfirm}
              className="py-2.5 px-4 rounded-xl sm:rounded-2xl bg-gradient-to-r from-red-600 to-amber-500 hover:brightness-110 text-white font-bold text-xs sm:text-base transition-all shadow-[0_4px_15px_rgba(239,68,68,0.3)] hover:scale-[1.02] cursor-pointer tv-focusable"
            >
              Resume
            </button>
            <button
              onClick={handleStartOverConfirm}
              className="py-2.5 px-4 rounded-xl sm:rounded-2xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 transition-all font-bold text-xs sm:text-base hover:scale-[1.02] cursor-pointer tv-focusable"
            >
              Start Over
            </button>
          </div>
        </motion.div>
      </div>
    );
  }, [showStartPopup, movie, savedResumeTime]);

  const headerBarContent = useMemo(() => {
    return (
      <div 
        className={`absolute top-0 left-0 right-0 p-4 sm:p-5 flex items-center justify-between bg-gradient-to-b from-black/95 via-black/80 to-transparent z-30 transition-all duration-300 select-none ${
          controlsVisible ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0 pointer-events-none"
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-650/15 flex items-center justify-center text-red-500 border border-red-500/20 shrink-0">
            <Film size={18} className="animate-pulse" />
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-display font-medium text-sm sm:text-base text-white truncate max-w-[180px] xs:max-w-[240px] sm:max-w-md">
                {isTrailer ? `🎬 Trailer | ${movie.movieName}` : movie.movieName}
              </h3>
              {isTrailer ? (
                <span className="shrink-0 text-[9px] font-mono font-black bg-amber-500 text-black border border-amber-500/25 px-1.5 py-0.5 rounded uppercase tracking-wider shadow-md">
                  TRAILER MODE
                </span>
              ) : (
                <span className="shrink-0 text-[10px] font-mono font-black bg-red-650 text-white border border-red-500/25 px-1.5 py-0.5 rounded uppercase tracking-wider shadow-md">
                  {movie.quality}
                </span>
              )}
              {!isTrailer && (
                <span className="shrink-0 text-[9px] font-mono font-bold bg-[#000000bd] text-gray-400 border border-white/5 px-2 py-0.5 rounded uppercase hidden xs:block">
                  SEEDED MIRRORS
                </span>
              )}
            </div>
            <p className="text-[10px] sm:text-xs text-gray-400 truncate mt-0.5">
              Directed by <span className="text-white font-medium">{movie.director || "Not Specified"}</span> • Starring <span className="text-white font-medium">{movie.starring || "Not Specified"}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Ambient Toggle */}
          <button 
            onClick={() => {
              const next = !ambientLights;
              setAmbientLights(next);
              try {
                localStorage.setItem("moviemachi_ambient_glow", JSON.stringify(next));
              } catch {}
            }}
            id="tv-btn-halos"
            className={`p-2 rounded-xl border transition-all duration-300 hidden sm:flex items-center gap-1.5 cursor-pointer tv-focusable focus:outline-none focus:ring-2 focus:ring-red-555 ${
              ambientLights 
                ? "bg-blue-600/15 text-blue-400 border-blue-500/30" 
                : "bg-white/5 text-gray-400 border-white/10 hover:bg-white/10"
            }`}
          >
            <Activity size={12} />
            <span className="text-[10px] uppercase font-mono font-bold tracking-wider">Halos</span>
          </button>

          {/* Exit/Close Player */}
          <button 
            onClick={handleClose}
            id="tv-btn-close"
            className="p-2 rounded-xl bg-white/5 hover:bg-red-650 hover:text-white text-gray-400 border border-white/10 hover:border-red-600/40 transition-all duration-200 cursor-pointer tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            <X size={16} />
          </button>
        </div>
      </div>
    );
  }, [controlsVisible, ambientLights, movie, isTrailer]);

  const settingsMenuContent = useMemo(() => {
    if (!showSettingsMenu) return null;
    return (
      <div 
        className="absolute bottom-16 xs:bottom-20 sm:bottom-24 left-4 right-4 sm:left-auto sm:right-6 sm:w-72 bg-[#09090fdd] backdrop-blur-2xl border border-white/10 rounded-2xl p-4 z-40 shadow-[0_10px_35px_rgba(0,0,0,0.9)] space-y-3 sm:space-y-4 max-h-[70vh] overflow-y-auto scrollbar-none"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="pb-2 border-b border-white/10 flex items-center justify-between">
          <h4 className="text-xs font-display font-black text-white uppercase tracking-wider flex items-center gap-1.5 text-red-500">
            <Settings size={14} className="animate-spin-slow" />
            <span>Cinema Settings</span>
          </h4>
          <button 
            onClick={() => setShowSettingsMenu(false)}
            className="text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={14} />
          </button>
        </div>

        {/* Speed Selector */}
        <div className="space-y-1.5">
          <span className="text-[9px] text-gray-500 uppercase tracking-widest font-mono font-bold">Playback Speed</span>
          <div className="grid grid-cols-4 gap-1">
            {[1, 1.25, 1.5, 2].map((speed) => (
              <button
                key={`speed-${speed}`}
                onClick={() => {
                  setPlaybackSpeed(speed);
                  if (videoRef.current) videoRef.current.playbackRate = speed;
                }}
                className={`py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                  playbackSpeed === speed 
                    ? "bg-red-650 text-white shadow-[0_0_8px_rgba(239,68,68,0.3)]" 
                    : "bg-white/5 text-gray-400 hover:bg-neutral-800 hover:text-white"
                }`}
              >
                {speed}x
              </button>
            ))}
          </div>
        </div>

        {/* Audio Track Selector */}
        <div className="space-y-1.5 pb-1">
          <span className="text-[9px] text-gray-500 uppercase tracking-widest font-mono font-bold">Audio Channels</span>
          <div className="space-y-1">
            {["Original (Tamil)", "Dual (Eng/Tam) Stereo", "DTS 5.1 Dolby"].map((track) => (
              <button
                key={`track-${track}`}
                onClick={() => {
                  setAudioTrack(track);
                }}
                className={`w-full py-2 px-3 rounded-lg text-xs text-left font-medium transition-all flex items-center justify-between cursor-pointer ${
                  audioTrack === track 
                    ? "bg-red-650/10 text-red-400 border border-red-500/20" 
                    : "bg-white/5 text-gray-400 hover:bg-neutral-800 hover:text-white border border-transparent"
                }`}
              >
                <span>{track}</span>
                {audioTrack === track && <Check size={12} className="text-red-400" />}
              </button>
            ))}
          </div>
        </div>

         {/* Ambient lights switch */}
        <div className="flex items-center justify-between pt-2 border-t border-white/5">
          <div className="flex items-center gap-2 text-sky-400">
            <Activity size={14} />
            <span className="text-xs text-gray-300 font-semibold font-sans">Ambient Aura Glow</span>
          </div>
          <button
            id="tv-switch-glow"
            onClick={() => {
              const next = !ambientLights;
              setAmbientLights(next);
              try {
                localStorage.setItem("moviemachi_ambient_glow", JSON.stringify(next));
              } catch {}
            }}
            className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-200 cursor-pointer tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500 ${ambientLights ? "bg-red-650" : "bg-neutral-800"}`}
          >
            <div className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${ambientLights ? "translate-x-4" : "translate-x-0"}`} />
          </button>
        </div>

      </div>
    );
  }, [showSettingsMenu, playbackSpeed, audioTrack, ambientLights]);

  const bottomControlsContent = useMemo(() => {
    return (
      <div className="flex flex-wrap items-center justify-center gap-2 md:flex-row md:flex-nowrap md:justify-between md:gap-4 h-auto">
        
        {/* Play trigger buttons, skip controls, and volume */}
        <div className="flex flex-wrap items-center justify-center gap-2 md:flex-nowrap md:gap-4 md:justify-start">
          <button 
            onClick={skipBackward}
            id="tv-btn-rewind"
            className="w-11 h-11 flex items-center justify-center md:w-auto md:h-auto md:p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 transition-all cursor-pointer border border-white/5 hover:border-white/10 tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500"
            title="Rewind 10s"
          >
            <Rewind size={14} />
          </button>

          <button 
            onClick={togglePlay}
            id="tv-btn-play"
            className="w-11 h-11 md:w-10 md:h-10 rounded-full bg-red-650 hover:bg-red-500 text-white flex items-center justify-center transition-all shadow-[0_0_15px_rgba(239,68,68,0.4)] cursor-pointer hover:scale-105 active:scale-95 tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            {isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
          </button>

          <button 
            onClick={skipForward}
            id="tv-btn-forward"
            className="w-11 h-11 flex items-center justify-center md:w-auto md:h-auto md:p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 transition-all cursor-pointer border border-white/5 hover:border-white/10 tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500"
            title="Fast Forward 10s"
          >
            <FastForward size={14} />
          </button>

          {/* Volume sliders with instant reactive mute logic */}
          <div className="flex items-center gap-1.5 pl-2 border-l border-white/10">
            <button 
              onClick={toggleMute}
              id="tv-btn-mute"
              className="w-11 h-11 flex items-center justify-center md:w-auto md:h-auto md:p-1.5 rounded-lg hover:bg-white/5 text-gray-300 transition-colors cursor-pointer tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              {isMuted || volume === 0 ? (
                <VolumeX size={14} className="text-red-400" />
              ) : volume < 0.45 ? (
                <Volume1 size={14} />
              ) : (
                <Volume2 size={14} />
              )}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={isMuted ? 0 : volume}
              onChange={(e) => handleVolumeChange(Number(e.target.value))}
              id="tv-slider-volume"
              className="w-14 sm:w-20 h-1 accent-red-500 bg-white/10 rounded-lg appearance-none cursor-pointer outline-none tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>
        </div>

        {/* Params settings triggers (audio feed toggle, gear parameters popup, fullscreen triggers) */}
        <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-gray-400 md:flex-nowrap md:gap-3.5 md:justify-end shrink-0">
          
          {/* Quick Audio track badge label */}
          <div className="hidden xs:flex h-11 md:h-auto items-center gap-1 px-2.5 md:py-1.5 rounded-xl bg-white/5 border border-white/5 text-[10px] font-semibold text-gray-300">
            <span className="text-gray-500 uppercase font-mono font-bold text-[9px]">FEED:</span>
            <span>{audioTrack.replace("Original ", "")}</span>
          </div>

          {/* Quick Speed rate Badge label */}
          <button
            onClick={handleSpeedToggle}
            id="tv-btn-speed"
            className="h-11 px-3 flex items-center justify-center md:h-auto md:px-2 md:py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 border border-white/5 transition-all font-mono font-bold text-[10px] sm:text-xs cursor-pointer tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500"
            title="Cycles speed rate directly"
          >
            {playbackSpeed}x
          </button>

          {/* Expanded parameter settings trigger */}
          <button
            onClick={() => setShowSettingsMenu(prev => !prev)}
            id="tv-btn-settings"
            className={`w-11 h-11 flex items-center justify-center md:w-auto md:h-auto md:p-2 rounded-xl transition-all duration-300 border cursor-pointer tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500 ${
              showSettingsMenu 
                ? "bg-red-650 text-white border-red-500/40 shadow-lg" 
                : "bg-white/5 text-gray-300 border-white/5 hover:bg-white/10"
            }`}
            title="Advanced options menu"
          >
            <Settings size={14} />
          </button>

          {/* Fullscreen handler trigger */}
          <button
            onClick={toggleFullscreen}
            id="tv-btn-fullscreen"
            className="w-11 h-11 flex items-center justify-center md:w-auto md:h-auto md:p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 transition-all border border-white/5 hover:border-white/10 cursor-pointer active:scale-95 tv-focusable focus:outline-none focus:ring-2 focus:ring-red-500"
            title="Toggles premium cinema fullscreen view"
          >
            {isFullscreen || isLayoutFullscreen ? <Minimize2 size={14} /> : <Maximize size={14} />}
          </button>
        </div>

      </div>
    );
  }, [isPlaying, volume, isMuted, playbackSpeed, showSettingsMenu, isFullscreen, isLayoutFullscreen, audioTrack]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 md:p-4 bg-black/95 backdrop-blur-3xl overflow-hidden select-none">
      
      {/* Upgraded High-Fidelity Ambient Aura Glow Backdrop */}
      <AnimatePresence>
        {ambientLights && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0 pointer-events-none z-0 overflow-hidden"
          >
            {ambientBackdropContent}
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div 
        ref={containerRef}
        initial={{ opacity: 0, scale: 0.98, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.98, y: 10 }}
        onMouseMove={handleUserInteraction}
        onClick={handleUserInteraction}
        onTouchStart={handleUserInteraction}
        style={{
          boxShadow: ambientLights 
            ? `0 20px 50px -15px rgba(0,0,0,0.85), 0 0 75px ${getGlowWithAlpha(0.4)}, 0 0 30px ${getGlowWithAlpha(0.2)}` 
            : "none"
        }}
        className={`relative w-full flex flex-col bg-[#020202] transition-all duration-300 overflow-hidden ${
          isFullscreen || isLayoutFullscreen
            ? "fixed inset-0 z-50 w-screen h-screen rounded-none max-w-none border-none shadow-none" 
            : "max-w-5xl rounded-3xl glass-panel border border-white/10 aspect-video my-auto"
        } ${isPlaying && !controlsVisible ? "cursor-none" : "cursor-default"}`}
      >
        {/* Permanent Close Button for Mobile and Fullscreen */}
        <button 
          onClick={handleClose}
          className="absolute top-[12px] right-[12px] z-[99999] w-10 h-10 rounded-full bg-black/60 hover:bg-red-650 text-white border border-white/10 hover:border-red-600/40 transition-all duration-200 cursor-pointer flex items-center justify-center shadow-lg"
          title="Close Player"
        >
          <X size={18} />
        </button>

        {/* Core Sandbox Video Box */}
        <div className="w-full h-full relative z-10 bg-black flex items-center justify-center grow">
          <video
            ref={videoRef}
            onClick={handleVideoClick}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onWaiting={handleWaiting}
            onPlaying={handlePlaying}
            preload="auto"
            className="w-full h-full object-contain bg-black max-h-full"
            playsInline
            onContextMenu={(e) => e.preventDefault()}
          />

          {/* Start Over / Resume Overlay Dialog */}
          <AnimatePresence>
            {showStartPopup && startOverDialogContent}
          </AnimatePresence>

          {/* Flash Feedback Popover */}
          <AnimatePresence>
            {showVolumeBadge && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="absolute z-40 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 px-5 py-3.5 bg-black/85 backdrop-blur-md rounded-2xl border border-white/10 text-white font-mono text-sm shadow-[0_0_20px_rgba(0,0,0,0.5)] flex items-center gap-2 pointer-events-none"
              >
                {isMuted || volume === 0 ? <VolumeX size={16} className="text-red-500" /> : <Volume2 size={16} className="text-red-400" />}
                <span>Volume: {Math.round((isMuted ? 0 : volume) * 100)}%</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Premium Loading Spinner Overlay */}
          {isLoading && (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/95 backdrop-blur-sm">
              <div className="relative flex items-center justify-center mb-5">
                <div className="w-16 h-16 rounded-full border-[3px] border-red-500/10 border-t-red-600 animate-spin" />
                <div className="absolute w-12 h-12 rounded-full border border-amber-500/10 border-b-amber-500 animate-spin [animation-duration:1.5s]" />
                <Film size={20} className="absolute text-red-500 animate-pulse" />
              </div>
              <h4 className="font-display text-white tracking-[0.25em] text-xs uppercase font-black">
                Buffering Cinema Stream
              </h4>
              <p className="text-[10px] text-gray-500 mt-2 font-mono">
                Connecting to premium high-resolution streams...
              </p>
            </div>
          )}

          {/* Custom Large Center Play Button Overlay (when paused) */}
          {!isPlaying && !isLoading && !showStartPopup && (
            <div 
              onClick={togglePlay}
              className="absolute inset-0 z-20 flex items-center justify-center bg-black/35 cursor-pointer group hover:bg-black/25 transition-colors"
            >
              <div className="w-20 h-20 rounded-full bg-red-650/10 group-hover:bg-red-600/20 border-2 border-red-500/25 group-hover:border-red-500/60 flex items-center justify-center text-red-500 group-hover:scale-110 transition-all duration-300 shadow-[0_0_35px_rgba(239,68,68,0.3)]">
                <Play size={32} fill="currentColor" className="ml-1 text-white" />
              </div>
            </div>
          )}

          {/* Premium Settings Overlay Menu */}
          <AnimatePresence>
            {settingsMenuContent}
          </AnimatePresence>
        </div>

        {/* CUSTOM GLASS TOP HEADER BAR (Slides down/up) */}
        {headerBarContent}

        {/* CUSTOM GLASS OVERLAY CONTROL PANEL (Slides up/down) */}
        <div 
          className={`absolute bottom-0 left-0 right-0 p-4 sm:p-5 bg-gradient-to-t from-black/95 via-black/85 to-transparent z-30 transition-all duration-300 select-none space-y-4 ${
            controlsVisible ? "translate-y-0 opacity-100" : "translate-y-full opacity-0 pointer-events-none"
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Custom Sleek Progress scrub timeline */}
          <div className="flex items-center gap-3">
            <span className="font-mono text-[10px] sm:text-xs text-gray-400 select-none shrink-0">{formatTime(currentTime)}</span>
            
            <div 
              ref={progressBarRef}
              onMouseMove={handleProgressBarMouseMove}
              onMouseLeave={handleProgressBarMouseLeave}
              onClick={handleProgressBarClick}
              className="relative flex-1 h-3 flex items-center cursor-pointer select-none group"
            >
              {/* Hover timestamp tooltip */}
              {hoverTime !== null && (
                <div 
                  className="absolute bottom-6 px-2 py-1 bg-[#09090f] border border-white/15 text-white text-[10px] font-mono font-bold rounded shadow-2xl -translate-x-1/2 pointer-events-none z-50 transform"
                  style={{ left: `${hoverX}px` }}
                >
                  {formatTime(hoverTime)}
                </div>
              )}

              {/* Progress track */}
              <div className="w-full h-1 bg-white/15 rounded-full overflow-hidden relative group-hover:h-2 transition-all duration-150">
                <div 
                  className="h-full bg-gradient-to-r from-red-600 via-red-500 to-amber-500 rounded-full relative shadow-[0_0_8px_#ef4444]"
                  style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
                >
                  {/* Glowing progress slider head thumb */}
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-white rounded-full shadow-[0_0_10px_#ef4444] scale-0 group-hover:scale-100 transition-transform duration-100 z-10" />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 font-mono text-[10px] sm:text-xs select-none shrink-0">
              <span className="text-gray-400" title="Remaining Time">-{formatTime(Math.max(0, duration - currentTime))}</span>
              <span className="text-gray-600">/</span>
              <span className="text-gray-200" title="Total Duration">{formatTime(duration)}</span>
            </div>
          </div>

          {/* Primary triggers and utility parameters controls bar */}
          {bottomControlsContent}
        </div>

      </motion.div>
    </div>
  );
}
