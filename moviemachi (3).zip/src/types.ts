/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface MovieLink {
  label: string;
  url: string;
  className: "Epi" | "p480" | "p720" | "p1080" | "K4" | string;
}

export interface Movie {
  title: string;
  image: string;
  movieName: string;
  director: string;
  starring: string;
  genres: string[];
  quality: string;
  language: string;
  rating: string;
  lastUpdated: string;
  links: MovieLink[];
  watchUrl?: string;
  trailerUrl?: string;
}
